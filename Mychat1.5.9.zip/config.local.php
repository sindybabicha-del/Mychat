<?php
// ─── Configuration locale — NE PAS committer dans Git ───────────────────────
// Copiez ce fichier à la racine du projet (à côté de api.php).
//
// ╔══════════════════════════════════════════════════════════════════════════╗
// ║  ⚠  ACTION REQUISE — FAILLE C-01 (CWE-798)                             ║
// ║  La clé sk_HGAfWBjumTfftxw9D01iq1wTA6HhSYC1 a été exposée.            ║
// ║  RÉVOQUEZ-LA IMMÉDIATEMENT dans le tableau de bord Pollinations et      ║
// ║  générez-en une nouvelle avant tout redéploiement.                      ║
// ╚══════════════════════════════════════════════════════════════════════════╝
//
// ── RECOMMANDATION SÉCURITÉ ─────────────────────────────────────────────────
// Préférez les variables d'environnement serveur (jamais sur le disque) :
//   Apache  :  SetEnv POLLINATIONS_API_KEY "votre_cle"  (VirtualHost / .htaccess)
//   Nginx   :  fastcgi_param POLLINATIONS_API_KEY "votre_cle";
//   Systemd :  Environment="POLLINATIONS_API_KEY=votre_cle"
//   Docker  :  ENV POLLINATIONS_API_KEY=votre_cle
//
// Ce fichier sert uniquement de fallback si la variable d'env est absente.
// Ne laissez JAMAIS une vraie clé en valeur littérale ici.

// Priorité 1 : variable d'environnement (recommandé)
// Priorité 2 : valeur ci-dessous (laisser le placeholder en production)
define(
    'POLLINATIONS_API_KEY',
    (string)(getenv('POLLINATIONS_API_KEY') ?: 'sk_HGAfWBjumTfftxw9D01iq1wTA6HhSYC1')
);

// ── Domaine canonique ───────────────────────────────────────────────────────
define(
    'SITE_CANONICAL_HOST',
    (string)(getenv('MYCHAT_CANONICAL_HOST') ?: 'votre-domaine.com')
);
