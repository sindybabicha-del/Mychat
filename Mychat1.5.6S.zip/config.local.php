<?php
// ─── Configuration locale — NE PAS committer dans Git ───────────────────────
// Copiez ce fichier à la racine du projet (à côté de api.php).

// ── Clé API Pollinations (requise pour le bot IA) ──────────────────────────
define('POLLINATIONS_API_KEY', 'sk_HGAfWBjumTfftxw9D01iq1wTA6HhSYC1');

// ── Domaine canonique — CORRIGE le bug d'upload d'images ───────────────────
// Remplacez par votre vrai domaine (sans https://, sans slash final).
// Exemples : 'monsite.com'  /  'www.monsite.com'  /  'user.github.io'
define('SITE_CANONICAL_HOST', 'votre-domaine.com');
