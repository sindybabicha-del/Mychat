// ─── FIX HÉBERGEURS GRATUITS (?i=1, ?i=0, ?i=2…) ───────────────────────────
// InfinityFree, 000WebHost et consorts ajoutent ?i=1 à l'URL pour le tracking.
// Cela peut casser les paramètres GET des appels API (les params sont perdus lors
// de la réécriture interne). On nettoie l'URL proprement au chargement.
(function fixFreeHostingParam() {
  try {
    const qs = window.location.search;
    if (qs && /[?&]i=\d/.test(qs)) {
      // Retirer ?i=X sans rechargement de page
      const clean = window.location.pathname + window.location.hash;
      history.replaceState(null, '', clean);
    }
  } catch (_) {}
})();

// ─── CONFIGURATION ──────────────────────────────────────────────────────────
const API_URL     = 'api.php';

// ─── Correction audit M-06 : intervalles adaptatifs selon la charge ──────────
// Réduit la pression sur le serveur quand le nombre d'utilisateurs augmente.
// Les seuils sont conservateurs pour rester sous 1000 req/min sur le serveur.
const BASE_POLL_INTERVAL      = 1900;  // ms — 1 poll/~2s par utilisateur
const BASE_HEARTBEAT_INTERVAL = 3000;  // ms — 1 heartbeat/3s par utilisateur
function getAdaptiveInterval(base) {
  const userCount = Object.keys(users).length;
  if (userCount > 50) return base * 3;
  if (userCount > 20) return base * 2;
  return base;
}

// ─── STATE ──────────────────────────────────────────────────────────────────
let me = null;
let users = {};
let typingUsers = {};
let uploadingUsers = {};
let pollTimer = null;
let heartbeatInterval = null;
let lastEventTs = 0;
let isTyping = false;
let typingBroadcastTimeout = null;
let activeChat = { type: 'room', id: null };
let allMessages = [];
// Historique local des conversations avec le bot IA, utilisé UNIQUEMENT côté client
// pour un affichage immédiat (indicateur de frappe du bot, déduplication du poll).
// Le vrai historique conversationnel est maintenu côté serveur dans bot_sessions.json.
// Ce tableau N'EST PAS envoyé au serveur — il ne peut donc pas être forgé en prompt injection.
const botHistory = {}; // contextKey → [{role:'user'|'assistant', content:str}]
const BOT_HISTORY_MAX = 20; // nb de tours max (1 tour = 1 user + 1 assistant)
let unreadDMs = {};
const silencedDMs = new Set(); // plus de son une fois la conv ouverte
// ─── Cache des nonces E2E déjà déchiffrés (anti-rejeu à court terme) ─────────
// Map nonce → timestamp, purgée automatiquement après 10 minutes.
// Empêche qu'un attaquant rejoue un DM capturé en changeant uniquement le msg.id externe.
const _seenNonces = new Map();
let lastAuthorId = null;
let apiOnline = false;
let initialUsersPollDone = false;
const absentCount = {}; // userId → nombre de polls consécutifs sans cet utilisateur

const rooms = { 'Général':'🌐', 'Tech':'💻', 'Musique':'🎵', 'Jeux':'🎮' };
const BOT_ID  = 'ia_bot_mychat';

// ─── CRYPTO STATE ────────────────────────────────────────────────────────────
let myKeyPair   = null;   // { publicKey, privateKey } RSA-OAEP CryptoKey (chiffrement)
let myPubKeyB64 = null;   // clé publique RSA sérialisée à envoyer
const pubKeys   = {};     // userId -> CryptoKey RSA (clés publiques des autres)

// ─── Paire ECDSA de signature (faille #1 — non-répudiation E2E) ──────────────
// Chaque client génère une paire ECDSA P-256 dédiée à la signature en plus de sa
// paire RSA-OAEP de chiffrement. L'expéditeur signe le message brut avant chiffrement ;
// le destinataire vérifie la signature après déchiffrement.
// Un serveur compromis ne peut pas forger un message d'Alice vers Bob
// sans sa clé privée ECDSA, même en connaissant sa clé RSA.
let mySignKeyPair   = null;  // { publicKey, privateKey } ECDSA P-256
let mySignPubKeyB64 = null;  // clé publique ECDSA sérialisée à envoyer
const signPubKeys   = {};    // userId -> CryptoKey ECDSA (pour vérification)

// ─── PRÉ-GÉNÉRATION ANTICIPÉE DE LA CLÉ E2E ──────────────────────────────────
// On lance immédiatement la génération de la paire RSA dès le chargement de la
// page, sans attendre le clic sur "Rejoindre". La génération (~200-600 ms) se
// déroule en arrière-plan pendant que l'utilisateur remplit le formulaire.
// La promesse est stockée ici : joinChat() l'attend si elle n'est pas encore
// résolue, ou récupère le résultat instantanément si elle l'est déjà.
//
// ⚠ RSA_ALGO et AES_ALGO sont déclarés ICI (avant l'appel initCrypto) pour éviter
// la Temporal Dead Zone (TDZ) des const.
// initCrypto() est une function déclarée (hoistée), mais les const eux ne sont PAS
// hoistés. Les référencer avant leur ligne de déclaration → ReferenceError.
// Solution : déplacer ces constantes avant le premier appel qui les utilise.
const RSA_ALGO = { name:'RSA-OAEP', modulusLength:2048, publicExponent:new Uint8Array([1,0,1]), hash:'SHA-256' };
const AES_ALGO = { name:'AES-GCM', length:256 };

let _cryptoReady = initCrypto();

// ─── SESSION TOKEN (stocké uniquement en mémoire, jamais dans localStorage) ──
let myToken = null;
// ─── Nonce de déconnexion beacon (renouvelé par chaque heartbeat) ─────────────
// Fourni par le serveur via le champ `beaconNonce` de la réponse heartbeat.
// Permet au sendBeacon fallback de prouver l'identité sans mettre le token dans le body.
let myBeaconNonce = null;

// ─── Correction audit C-02 : Token CSRF ──────────────────────────────────────
// Lié au token de session via HMAC serveur. Renouvelé automatiquement avant expiration.
let _csrfToken     = null;
let _csrfTs        = 0;
let _csrfExpiresAt = 0;

// ─── RGPD : consentement envoi d'images au bot IA (correction audit #4) ──────
// Les images envoyées au bot sont transmises à gen.pollinations.ai (service tiers).
// L'utilisateur doit y consentir explicitement au moins une fois par session.
// On stocke le consentement en mémoire (sessionStorage : reset à chaque fermeture d'onglet).
let _botImageConsentGiven = (() => {
  try { return sessionStorage.getItem('mychat_bot_img_consent') === '1'; } catch { return false; }
})();

/**
 * Demande le consentement RGPD pour l'envoi d'une image à gen.pollinations.ai.
 * Résout avec true si l'utilisateur accepte, false sinon.
 */
function requestBotImageConsent() {
  return new Promise(resolve => {
    if (_botImageConsentGiven) { resolve(true); return; }

    const overlay = document.createElement('div');
    overlay.style.cssText = [
      'position:fixed','inset:0','background:rgba(0,0,0,0.75)','z-index:99998',
      'display:flex','align-items:center','justify-content:center','font-family:inherit','padding:16px',
    ].join(';');

    const box = document.createElement('div');
    box.style.cssText = [
      'background:#1e1e2e','border:2px solid #6366f1','border-radius:12px',
      'padding:24px','max-width:460px','width:100%','color:#e2e8f0',
      'box-shadow:0 20px 60px rgba(0,0,0,0.6)',
    ].join(';');

    box.innerHTML = `
      <div style="font-size:1.3em;margin-bottom:12px">🤖 Analyse d'image par l'IA</div>
      <p style="margin:0 0 12px;line-height:1.5">
        Pour analyser cette image, le serveur va la transmettre à
        <strong>gen.pollinations.ai</strong> (service tiers externe) sous forme encodée.
      </p>
      <p style="margin:0 0 16px;font-size:0.9em;color:#94a3b8;line-height:1.5">
        ⚠️ Ne soumettez pas d'images contenant des données personnelles sensibles,
        des visages sans consentement, ou des informations confidentielles.<br><br>
        Ce consentement s'applique à la session en cours.
      </p>
      <div style="display:flex;gap:10px;justify-content:flex-end">
        <button id="botConsentRefuse" style="background:#374151;color:#e2e8f0;border:none;border-radius:6px;padding:8px 18px;cursor:pointer">
          Annuler
        </button>
        <button id="botConsentAccept" style="background:#6366f1;color:#fff;border:none;border-radius:6px;padding:8px 18px;font-weight:bold;cursor:pointer">
          J'accepte pour cette session
        </button>
      </div>`;

    overlay.appendChild(box);
    document.body.appendChild(overlay);

    box.querySelector('#botConsentAccept').addEventListener('click', () => {
      _botImageConsentGiven = true;
      try { sessionStorage.setItem('mychat_bot_img_consent', '1'); } catch {}
      overlay.remove();
      resolve(true);
    });
    box.querySelector('#botConsentRefuse').addEventListener('click', () => {
      overlay.remove();
      resolve(false);
    });
  });
}

// ─── HELPERS ────────────────────────────────────────────────────────────────
function genId() {
  // Correction audit B-04 : supprimer Date.now() qui fuitait l'horodatage exact d'émission.
  // 16 octets aléatoires cryptographiquement sûrs = 128 bits d'entropie, collision impossible.
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return Array.from(arr).map(b => b.toString(36).padStart(2,'0')).join('').slice(0, 20);
}
function getTime() {
  const n = new Date();
  return n.getHours().toString().padStart(2,'0') + ':' + n.getMinutes().toString().padStart(2,'0');
}
// ─── Correction audit B-01 : escHtml encode désormais les apostrophes ──────────
// L'ancienne version n'encodait pas ' (guillemet simple). Dans tout attribut HTML
// simple-quoté (ex : onclick='…') injecter une apostrophe suffit à terminer
// l'attribut et exécuter du JS arbitraire. L'encodage défensif en &#x27; est une
// bonne pratique même si les attributs sont actuellement double-quotés.
function escHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
}
// ─── Correction audit B-02 : formatMsg utilise des callbacks de remplacement ──
// L'ancienne version utilisait des chaînes de remplacement ('$1') susceptibles
// d'interpréter les séquences spéciales JS ($&, $', $`, $n) si le texte capturé
// contenait un '$' suivi d'un de ces caractères.
// Ex : **hello $'** → '<strong>' + [tout ce qui suit le match] + '</strong>'
// Le passage à une fonction callback (m, p1) => '...' + p1 + '...' supprime
// complètement ce vecteur : la valeur de p1 est traitée comme une chaîne littérale.
function formatMsg(text) {
  // Correction audit H-02 : le serveur stocke désormais le texte via htmlspecialchars().
  // Le texte reçu est DÉJÀ HTML-safe — ne pas appeler escHtml() ici pour éviter le double-encodage.
  // Les messages locaux (own) et les DM déchiffrés sont escapés à la source (voir sendMessage / processEvent).
  const safe = text.slice(0, 4000);
  return safe
    // Regex bornées : {1,200} évite le catastrophic backtracking sur des inputs pathologiques
    // Callbacks de remplacement (correction audit B-02) : p1 est toujours traité comme
    // une chaîne littérale — aucune interpolation de séquences spéciales ($&, $', $`…).
    .replace(/\*\*(.{1,200}?)\*\*/g, (_, p1) => '<strong>' + p1 + '</strong>')
    .replace(/\*(.{1,200}?)\*/g,    (_, p1) => '<em>'     + p1 + '</em>')
    .replace(/\n/g, '<br>');
}

/**
 * Valide qu'une imageUrl pointe bien vers notre propre API (anti-XSS).
 * Rejette toute URL externe, javascript:, data:, etc.
 */
function isSafeImageUrl(url) {
  if (!url || typeof url !== 'string') return false;
  return /^api\.php\?action=get_image&id=[a-f0-9]{32}$/.test(url);
}

// ─── CRYPTO E2E ──────────────────────────────────────────────────────────────
// RSA_ALGO et AES_ALGO sont déclarés plus haut (avant initCrypto()) — voir section CRYPTO STATE.

// ─── Note architecturale faille #5 — Perfect Forward Secrecy (PFS) ───────────
// Le schéma actuel : une paire RSA par session, une clé AES-256 éphémère par message.
// PFS GARANTIE AU NIVEAU DU MESSAGE : si la clé AES d'un message est compromise,
// cela n'affecte pas les autres messages (chaque AES est indépendante).
// LIMITATION : si la clé RSA privée est compromise PENDANT la session en cours,
// tous les messages de cette session restent déchiffrables par l'attaquant.
// Une architecture ECDH par session (ex : Signal X3DH/Double Ratchet) éliminerait
// cette fenêtre, mais est incompatible avec un polling HTTP sans état persistant.
// Atténuations actuelles :
//   - La clé RSA est non-extractable (extractable:false) → résistante à XSS
//   - La clé RSA est en mémoire uniquement → purged à la fermeture de l'onglet
//   - Durée de vie de la session = durée de l'onglet (pas de persistance inter-sessions)
//   - Chaque message a sa propre clé AES → compromission partielle uniquement

const ECDSA_ALGO = { name: 'ECDSA', namedCurve: 'P-256' };
const ECDSA_SIGN = { name: 'ECDSA', hash: 'SHA-256' };

async function initCrypto() {
  // Paire RSA-OAEP pour le chiffrement des messages DM
  myKeyPair   = await crypto.subtle.generateKey(RSA_ALGO, false, ['encrypt','decrypt']);
  const jwk   = await crypto.subtle.exportKey('jwk', myKeyPair.publicKey);
  myPubKeyB64 = btoa(JSON.stringify(jwk));

  // ─── Correction faille #1 — Paire ECDSA P-256 pour la signature (non-répudiation) ─
  // La clé privée est extractable:false (identique à RSA) : un script XSS ne peut pas
  // l'exporter. La clé publique est extraite ici pour être diffusée via join/heartbeat.
  mySignKeyPair   = await crypto.subtle.generateKey(ECDSA_ALGO, false, ['sign','verify']);
  const signJwk   = await crypto.subtle.exportKey('jwk', mySignKeyPair.publicKey);
  mySignPubKeyB64 = btoa(JSON.stringify(signJwk));
}

async function importPubKey(b64) {
  try {
    const jwk = JSON.parse(atob(b64));
    return await crypto.subtle.importKey('jwk', jwk, RSA_ALGO, false, ['encrypt']);
  } catch { return null; }
}

/** Importe une clé publique ECDSA P-256 (pour vérification de signature). */
async function importSignPubKey(b64) {
  try {
    const jwk = JSON.parse(atob(b64));
    return await crypto.subtle.importKey('jwk', jwk, ECDSA_ALGO, false, ['verify']);
  } catch { return null; }
}

/**
 * Calcule l'empreinte SHA-256 d'une clé publique exportée en JWK.
 * Permet à l'utilisateur de vérifier hors-bande que la clé n'a pas été substituée
 * par un attaquant intermédiaire (le serveur est un point de transit des clés).
 */
async function computeKeyFingerprint(b64) {
  try {
    const raw    = new TextEncoder().encode(b64);
    const digest = await crypto.subtle.digest('SHA-256', raw);
    return Array.from(new Uint8Array(digest))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('')
      .slice(0, 16)  // 8 octets affichés en hex = suffisant pour une vérification visuelle
      .replace(/(.{4})/g, '$1 ').trim();
  } catch { return null; }
}

function b64e(buf) { return btoa(String.fromCharCode(...new Uint8Array(buf))); }
function b64d(s)   { return Uint8Array.from(atob(s), c => c.charCodeAt(0)); }

async function encryptDM(plainText, recipientPubKey) {
  // Générer une clé AES éphémère
  const aesKey = await crypto.subtle.generateKey(AES_ALGO, true, ['encrypt','decrypt']);
  const iv     = crypto.getRandomValues(new Uint8Array(12));
  // ─── Anti-rejeu : timestamp + senderId + nonce UUID unique ──────────────
  // Correction faille #4 : ajout d'un nonce aléatoire (UUID v4) dans l'enveloppe
  // chiffrée. Le destinataire vérifie que ce nonce n'a pas déjà été traité dans les
  // 10 dernières minutes, empêchant le rejeu même si l'attaquant modifie le msg.id
  // externe (en clair) pour soumettre un ciphertext valide comme "nouveau" message.
  const envelope = JSON.stringify({ m: plainText, ts: Date.now(), sid: me?.id || '', nonce: crypto.randomUUID() });
  const enc    = new TextEncoder();
  const ct     = await crypto.subtle.encrypt({ name:'AES-GCM', iv }, aesKey, enc.encode(envelope));
  // Envelopper la clé AES avec RSA-OAEP du destinataire
  const rawKey = await crypto.subtle.exportKey('raw', aesKey);
  const wrappedKey = await crypto.subtle.encrypt({ name:'RSA-OAEP' }, recipientPubKey, rawKey);

  // ─── Correction faille #1 — Signature ECDSA (non-répudiation) ─────────────
  // On signe la payload chiffrée (ct) + l'IV (pas le plaintext pour ne pas l'exposer).
  // Signer sur le ciphertext garantit : 1) que l'auteur possède la clé privée ECDSA
  // correspondant à la clé publique diffusée dans join/heartbeat, 2) qu'un serveur
  // compromis qui réemballerait le ct ne pourrait pas produire une signature valide.
  // La vérification côté destinataire porte donc sur ct+iv ensemble.
  let sig = null;
  if (mySignKeyPair?.privateKey) {
    const sigData = enc.encode(b64e(ct) + '|' + b64e(iv));
    const rawSig  = await crypto.subtle.sign(ECDSA_SIGN, mySignKeyPair.privateKey, sigData);
    sig = b64e(rawSig);
  }

  const payload = { enc: true, k: b64e(wrappedKey), iv: b64e(iv), ct: b64e(ct) };
  if (sig) payload.sig = sig;
  return JSON.stringify(payload);
}

/**
 * Déchiffre un DM, vérifie son enveloppe anti-rejeu et la signature ECDSA.
 * @param {string} payload          - JSON chiffré produit par encryptDM
 * @param {string} [expectedSender] - userId déclaré par le serveur pour ce message
 */
async function decryptDM(payload, expectedSender) {
  try {
    const parsed = JSON.parse(payload);
    const { k, iv, ct, sig } = parsed;

    // ─── Vérification signature ECDSA — politique stricte (anti-downgrade) ──────
    // Correction faille #2 : la vérification n'est PLUS conditionnée à la présence
    // préalable de signPubKeys[expectedSender]. Si la clé est absente, on la réclame
    // immédiatement via get_pubkey. Si elle reste introuvable, le message est rejeté.
    // Cela neutralise l'attaque où un serveur compromis supprime signPubKey des events
    // join/heartbeat pour que le client ne stocke jamais la clé → skip silencieux.
    if (expectedSender) {
      // Tenter de récupérer la clé ECDSA si elle n'est pas encore connue
      if (!signPubKeys[expectedSender]) {
        try {
          const res = await apiGetAuth({ action: 'get_pubkey', userId: expectedSender });
          if (res?.signPubKey) {
            const imported = await importSignPubKey(res.signPubKey);
            if (imported) signPubKeys[expectedSender] = imported;
          }
        } catch (_) { /* réseau — rejet ci-dessous si clé toujours absente */ }
      }
      // La clé est maintenant obligatoire : absent = rejet catégorique
      if (!signPubKeys[expectedSender]) {
        return '⚠️ [Message rejeté — clé de signature ECDSA introuvable (possible attaque de rétrogradation)]';
      }
      if (!sig) {
        return '⚠️ [Message rejeté — signature absente (possible attaque de rétrogradation)]';
      }
      const enc2    = new TextEncoder();
      const sigData = enc2.encode(ct + '|' + iv);
      const valid   = await crypto.subtle.verify(ECDSA_SIGN, signPubKeys[expectedSender], b64d(sig), sigData);
      if (!valid) {
        return '⚠️ [Message rejeté — signature invalide (possible usurpation ou falsification)]';
      }
    }

    // Déchiffrer la clé AES avec notre clé privée RSA
    const rawKey = await crypto.subtle.decrypt({ name: 'RSA-OAEP' }, myKeyPair.privateKey, b64d(k));
    const aesKey = await crypto.subtle.importKey('raw', rawKey, AES_ALGO, false, ['decrypt']);
    // Déchiffrer le message
    const dec   = new TextDecoder();
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64d(iv) }, aesKey, b64d(ct));
    const raw   = dec.decode(plain);

    // ─── Vérification anti-rejeu (timestamp + senderId) ─────────────────────
    // Correction faille #1 : le fallback v1 silencieux a été SUPPRIMÉ.
    // Un message dont le déchiffrement réussit mais dont l'enveloppe JSON est
    // absente ou invalide doit être REJETÉ catégoriquement — jamais retourné brut.
    // Cela empêche un client malveillant de chiffrer un texte arbitraire sans
    // enveloppe pour bypasser les contrôles de timestamp et d'identité expéditeur.
    let env;
    try {
      env = JSON.parse(raw);
    } catch (_) {
      return '⚠️ [Message rejeté — enveloppe non parseable (format obsolète ou falsifié)]';
    }
    if (!env || typeof env !== 'object' || !('ts' in env) || !('sid' in env)) {
      return '⚠️ [Message rejeté — format d\'enveloppe invalide (champs ts/sid absents)]';
    }
    const age = Date.now() - env.ts;
    if (age > 5 * 60 * 1000 || age < -30_000) {
      return '⚠️ [Message rejeté — horodatage invalide ou trop ancien (possible rejeu)]';
    }
    if (expectedSender && env.sid !== expectedSender) {
      return '⚠️ [Message rejeté — identité expéditeur incohérente (possible usurpation)]';
    }

    // ─── Correction faille #4 : vérification anti-rejeu à court terme (nonce UUID) ─
    // On vérifie que le nonce interne (env.nonce) n'a pas déjà été vu récemment.
    // Cela empêche un attaquant de rejouer un DM capturé en changeant uniquement
    // le msg.id externe (en clair), tout en gardant le même ciphertext valide.
    if (env.nonce) {
      const now = Date.now();
      // Purger les nonces plus vieux que 10 minutes
      for (const [nonce, ts] of _seenNonces) {
        if (now - ts > 10 * 60 * 1000) _seenNonces.delete(nonce);
      }
      if (_seenNonces.has(env.nonce)) {
        return '⚠️ [Message rejeté — nonce déjà vu (attaque par rejeu détectée)]';
      }
      _seenNonces.set(env.nonce, now);
    }

    return env.m ?? '';
  } catch { return '🔒 [Message illisible — clé introuvable]'; }
}

function isEncryptedPayload(text) {
  try { const o = JSON.parse(text); return o?.enc === true; } catch { return false; }
}

/**
 * Récupère immédiatement la clé publique RSA d'un utilisateur via l'endpoint get_pubkey.
 * Appelée à l'ouverture d'un DM si la clé n'est pas encore dans pubKeys[userId].
 * En cas d'échec (utilisateur pas encore dans events.json), on laisse le poll classique
 * prendre le relais au prochain cycle (~1,9 s).
 */
async function fetchPubKeyForUser(userId) {
  if (!userId || pubKeys[userId] || !me) return;
  try {
    const res = await apiGetAuth({ action: 'get_pubkey', userId });
    if (!res?.pubKey) return; // clé pas encore disponible → le poll classique prendra le relais
    // Si la clé est arrivée entre-temps via le poll, ne pas écraser
    if (pubKeys[userId]) return;
    const k = await importPubKey(res.pubKey);
    if (!k) return;
    pubKeys[userId] = k;
    const fp = await computeKeyFingerprint(res.pubKey);
    if (fp) {
      pubKeys[userId]._fingerprint = fp;
      // Vérification TOFU identique au chemin poll/heartbeat
      const targetUser = users[userId];
      if (targetUser) checkTofuFingerprint(userId, targetUser.name || userId, fp);
    }
    // Mettre à jour le badge uniquement si le DM est encore ouvert avec ce même user
    if (activeChat.type === 'private' && activeChat.id === userId) {
      updateE2eBadge();
    }
  } catch (_) { /* échec réseau → le poll classique prendra le relais */ }
}

function updateE2eBadge() {
  const badge = document.getElementById('e2eBadge');
  if (!badge) return;
  if (activeChat.type !== 'private') { badge.className = 'e2e-badge'; return; }
  const hasPubKey = !!pubKeys[activeChat.id];
  badge.className = 'e2e-badge ' + (hasPubKey ? 'active' : 'pending');
  const fp = pubKeys[activeChat.id]?._fingerprint;
  const fpText = fp ? ` · 🔑 ${fp}` : '';
  // L'empreinte permet à l'utilisateur de vérifier hors-bande (signal, IRL...)
  // que la clé n'a pas été substituée par le serveur (Man-in-the-Middle des clés publiques)
  document.getElementById('e2eBadgeText').textContent = hasPubKey
    ? `Chiffré E2E${fpText}`
    : 'En attente de clé…';
  // Avertissement TOFU : le serveur est un point de transit des clés publiques.
  // Un opérateur du serveur pourrait substituer une clé. La vérification hors-bande
  // de l'empreinte est le seul moyen de s'assurer de l'absence de MITM.
  const tofu = fp
    ? `Empreinte : ${fp}\n⚠ Le serveur transmet les clés — vérifiez cette empreinte hors-bande\n(ex. Signal, IRL) avec votre interlocuteur pour garantir l'absence de MITM.`
    : '⚠ Chiffrement E2E actif — clé non encore reçue.\nLe serveur transmet les clés publiques : vérifiez toujours l\'empreinte hors-bande.';
  if (badge) badge.title = tofu;
}
// ─── TOFU : persistance des empreintes de clés publiques ─────────────────────
// Les empreintes (fingerprints SHA-256 tronqués) sont stockées dans localStorage
// pour détecter un changement de clé entre sessions (attaque MITM possible via serveur).
// IMPORTANT : on ne persiste QUE l'empreinte (16 hex = 8 octets), jamais la clé elle-même.
// Audit #7 : localStorage est accessible via XSS, mais il n'y a pas d'alternative
// plus sûre pour de la persistance inter-sessions côté navigateur (IndexedDB et
// sessionStorage ont les mêmes limites). La CSP stricte (pas d'inline, pas d'eval)
// constitue la vraie défense contre XSS — le localStorage est acceptable pour les
// empreintes seules, qui ne permettent pas à un attaquant d'usurper une identité.
// Protections ajoutées : validation du format à la lecture et cap à 500 entrées
// pour éviter un stockage excessif causé par des userId forgés.
const _tofuKey = 'mychat_key_fps_v1'; // versionnée pour invalider proprement si le format change
let _storedFingerprints = {};
try {
  const raw = JSON.parse(localStorage.getItem(_tofuKey) || '{}');
  // Validation défensive : ne conserver que les entrées au format attendu (userId → hex 16 chars)
  // et limiter le nombre total pour prévenir un gonflement malveillant du localStorage.
  if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
    let count = 0;
    for (const [k, v] of Object.entries(raw)) {
      if (typeof k === 'string' && k.length <= 32 && /^[a-z0-9]+$/i.test(k)
          && typeof v === 'string' && /^[0-9a-f ]{16,24}$/.test(v)
          && count < 500) {
        _storedFingerprints[k] = v;
        count++;
      }
    }
  }
} catch (_) { _storedFingerprints = {}; }

function saveTofuFingerprints() {
  try { localStorage.setItem(_tofuKey, JSON.stringify(_storedFingerprints)); } catch (_) {}
}

/**
 * Correction audit #6 / M-04 — Alerte TOFU modale persistante avec confirmation explicite.
 *
 * Changements audit M-04 :
 *   - showTofuAlert() retourne une Promise<boolean>.
 *   - L'utilisateur doit cliquer "Faire confiance à cette nouvelle clé" pour persister
 *     la nouvelle empreinte. Sans cette action, localStorage N'EST PAS mis à jour.
 *   - Bouton "Rejeter" disponible pour une réponse de sécurité immédiate.
 *   - Délai minimum de 8 s maintenu sur les deux boutons.
 *
 * Correction audit F-01 : utilisation de escHtml() pour tous les champs interpolés
 *   (au lieu d'un échappement partiel qui omettait & et ").
 */
function showTofuAlert(userName, oldFp, newFp) {
  return new Promise(resolve => {
    // Correction audit F-01 : escHtml() gère &, <, >, " et '
    const safeName = escHtml(String(userName));
    const safeOld  = escHtml(String(oldFp));
    const safeNew  = escHtml(String(newFp));

    // Supprimer une éventuelle alerte TOFU existante (double changement rapide)
    document.getElementById('tofuAlertModal')?.remove();

    const overlay = document.createElement('div');
    overlay.id = 'tofuAlertModal';
    overlay.style.cssText = [
      'position:fixed', 'inset:0', 'background:rgba(0,0,0,0.75)', 'z-index:99999',
      'display:flex', 'align-items:center', 'justify-content:center',
      'font-family:inherit', 'padding:16px',
    ].join(';');

    const box = document.createElement('div');
    box.style.cssText = [
      'background:#1e1e2e', 'border:2px solid #f59e0b', 'border-radius:12px',
      'padding:24px', 'max-width:500px', 'width:100%', 'color:#e2e8f0',
      'box-shadow:0 20px 60px rgba(0,0,0,0.6)',
    ].join(';');

    box.innerHTML = `
      <div style="font-size:1.4em;margin-bottom:12px">⚠️ Changement de clé E2E détecté</div>
      <p style="margin:0 0 12px;line-height:1.5">
        La clé de chiffrement de <strong>${safeName}</strong> a changé depuis votre dernière session.<br>
        Cela peut indiquer une <strong>reconnexion normale</strong> ou, dans les cas graves,
        une substitution de clé par le serveur (<em>attaque MITM</em>).
      </p>
      <div style="background:#0f172a;border-radius:8px;padding:12px;font-family:monospace;font-size:0.85em;margin-bottom:12px">
        <div style="color:#94a3b8;margin-bottom:4px">Ancienne empreinte :</div>
        <div style="color:#f87171">${safeOld}</div>
        <div style="color:#94a3b8;margin-top:8px;margin-bottom:4px">Nouvelle empreinte :</div>
        <div style="color:#4ade80">${safeNew}</div>
      </div>
      <p style="margin:0 0 12px;font-size:0.9em;color:#94a3b8">
        🔑 Vérifiez cette empreinte hors-bande avec ${safeName} (Signal, IRL, email chiffré…)
        avant de faire confiance à cette clé.
      </p>
      <p style="margin:0 0 16px;font-size:0.85em;color:#f59e0b">
        ⚠ Tant que vous n'avez pas confirmé, l'empreinte précédente reste la référence.
      </p>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button id="tofuAlertReject"
          style="background:#374151;color:#e2e8f0;border:none;border-radius:6px;padding:8px 16px;
                 font-weight:bold;cursor:not-allowed;opacity:0.5;flex:1" disabled>
          Rejeter (8s)
        </button>
        <button id="tofuAlertTrust"
          style="background:#f59e0b;color:#000;border:none;border-radius:6px;padding:8px 16px;
                 font-weight:bold;cursor:not-allowed;opacity:0.5;flex:2" disabled>
          Faire confiance à cette clé (8s)
        </button>
      </div>`;

    overlay.appendChild(box);
    document.body.appendChild(overlay);

    let countdown = 8;
    const btnReject = box.querySelector('#tofuAlertReject');
    const btnTrust  = box.querySelector('#tofuAlertTrust');
    const timer = setInterval(() => {
      countdown--;
      if (countdown <= 0) {
        clearInterval(timer);
        [btnReject, btnTrust].forEach(b => { b.disabled = false; b.style.cursor = 'pointer'; b.style.opacity = '1'; });
        btnReject.textContent = 'Rejeter';
        btnTrust.textContent  = 'Faire confiance à cette clé';
      } else {
        btnReject.textContent = `Rejeter (${countdown}s)`;
        btnTrust.textContent  = `Faire confiance à cette clé (${countdown}s)`;
      }
    }, 1000);

    // "Faire confiance" → persister la nouvelle empreinte ET fermer
    btnTrust.addEventListener('click', () => { clearInterval(timer); overlay.remove(); resolve(true); });
    // "Rejeter" → NE PAS persister, fermer
    btnReject.addEventListener('click', () => { clearInterval(timer); overlay.remove(); resolve(false); });
    // Clic overlay (après délai) → rejeter silencieusement
    overlay.addEventListener('click', e => {
      if (e.target === overlay && !btnTrust.disabled) { clearInterval(timer); overlay.remove(); resolve(false); }
    });
  });
}

/**
 * Correction audit M-04 — Vérifie une empreinte TOFU pour un userId donné.
 * - Première fois vu → enregistre l'empreinte (Trust On First Use).
 * - Empreinte identique à celle connue → ok silencieux.
 * - Empreinte DIFFÉRENTE → alerte modale ; la mise à jour de localStorage n'a lieu
 *   QUE si l'utilisateur clique "Faire confiance" (Promise résolue à true).
 *   Précédemment, l'empreinte était mise à jour immédiatement sans confirmation,
 *   ce qui permettait à une clé frauduleuse d'être mémorisée après une seule alerte.
 */
function checkTofuFingerprint(userId, userName, fingerprint) {
  if (!fingerprint || !userId) return true;
  const known = _storedFingerprints[userId];
  if (!known) {
    // Première observation : enregistrer (Trust On First Use)
    _storedFingerprints[userId] = fingerprint;
    saveTofuFingerprints();
    return true;
  }
  if (known === fingerprint) return true; // clé inchangée

  // ⚠ DIVERGENCE : la clé a changé depuis la dernière session.
  // Correction audit M-04 : on affiche l'alerte et on attend la décision explicite
  // de l'utilisateur avant de mettre à jour localStorage.
  // Correction audit B-02 : console.warn supprimés — exposaient des empreintes et noms d'utilisateurs.
  showTofuAlert(userName, known, fingerprint).then(trusted => {
    if (trusted) {
      // L'utilisateur a explicitement fait confiance → mémoriser la nouvelle empreinte
      _storedFingerprints[userId] = fingerprint;
      saveTofuFingerprints();
    }
    // Rejet ou timeout → ne PAS mettre à jour localStorage
  });
  return false; // signale la divergence (l'appelant peut afficher un badge d'avertissement)
}

/**
 * Supprime l'empreinte TOFU d'un utilisateur (ex : après déconnexion confirmée).
 * Permet à un utilisateur de "réinitialiser" la confiance pour son propre compte.
 */
function clearTofuFingerprint(userId) {
  if (!userId) return;
  delete _storedFingerprints[userId];
  saveTofuFingerprints();
}

// Nettoyer les empreintes des utilisateurs qui viennent de quitter
// (appelé depuis processEvent sur type='leave')
function onUserLeft(userId) {
  // On ne supprime PAS l'empreinte au départ : on veut précisément détecter
  // si la clé change à la reconnexion suivante.
  // On nettoie uniquement via clearTofuFingerprint() sur action explicite de l'utilisateur.
  void userId; // ─── Correction B-05 : no-op explicite sans assignation de variable globale implicite
}

// ─── CONTOURNEMENT AUTOMATIQUE DU COOKIE HÉBERGEUR GRATUIT ──────────────────
// InfinityFree / 000WebHost interceptent TOUTES les requêtes (y compris fetch/XHR)
// tant que leur cookie de tracking (?i=1) n'est pas posé.
// Solution : charger api.php dans une iframe cachée → le navigateur exécute le
// challenge JS de l'hébergeur, le cookie est déposé, l'iframe se redirige.
// Après ça, toutes les requêtes fetch passent normalement — sans rechargement de page.

/**
 * Charge api.php dans une iframe invisible pour déclencher le challenge cookie
 * des hébergeurs gratuits (InfinityFree, 000WebHost…).
 * Résout une fois que l'iframe a chargé (ou après timeout).
 * @param {number} timeoutMs — délai max avant de résoudre quand même (défaut 9s)
 */
function warmupFreeHostCookie(timeoutMs = 9000) {
  return new Promise(resolve => {
    // Créer une iframe totalement invisible et inerte
    const iframe = document.createElement('iframe');
    iframe.setAttribute('aria-hidden', 'true');
    iframe.style.cssText = [
      'position:fixed', 'top:-9999px', 'left:-9999px',
      'width:1px', 'height:1px', 'border:0',
      'visibility:hidden', 'pointer-events:none',
    ].join(';');
    // Paramètre _warmup=1 ignoré par api.php mais évite un conflit de cache
    iframe.src = API_URL + '?_warmup=1';

    let settled = false;
    const settle = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      // Laisser ~500ms pour que le navigateur enregistre le cookie
      // avant que les fetch suivants soient émis
      setTimeout(() => { try { iframe.remove(); } catch (_) {} resolve(); }, 500);
    };

    const timer = setTimeout(settle, timeoutMs);
    iframe.addEventListener('load',  settle);
    iframe.addEventListener('error', settle);
    document.body.appendChild(iframe);
  });
}

// Lancer le warmup cookie dès le chargement de la page, en tâche de fond.
// Dans la majorité des cas il sera terminé avant que l'utilisateur clique sur
// "Rejoindre", sans aucune action de sa part.
let _warmupPromise = warmupFreeHostCookie();

/**
 * Correction audit C-02 — Gestion du token CSRF.
 * Demande un nouveau token au serveur si absent ou expiré.
 * Le token est valide 15 min côté serveur ; on le renouvelle après 12 min côté client.
 */
async function getCsrfToken() {
  if (_csrfToken && Date.now() < _csrfExpiresAt) {
    return { token: _csrfToken, ts: _csrfTs };
  }
  try {
    const r = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Auth-Token': myToken || '',
        'X-User-Id':   me?.id  || '',
      },
      body: JSON.stringify({ action: 'get_csrf' }),
    });
    const data = JSON.parse(await r.text());
    if (data?.csrfToken) {
      _csrfToken     = data.csrfToken;
      _csrfTs        = data.csrfTs;
      _csrfExpiresAt = Date.now() + 12 * 60 * 1000; // renouveler avant les 15 min
    }
  } catch (_) {}
  return { token: _csrfToken, ts: _csrfTs };
}

async function apiPost(data) {
  try {
    // Le token transite dans les headers HTTP (jamais dans l'URL, réduit l'exposition dans les logs)
    const headers = { 'Content-Type': 'application/json' };
    if (myToken && me?.id) {
      headers['X-Auth-Token'] = myToken;
      headers['X-User-Id']   = me.id;
      // ─── Correction audit C-02 : headers CSRF pour les endpoints mutants ────
      const csrf = await getCsrfToken();
      if (csrf.token) {
        headers['X-CSRF-Token'] = csrf.token;
        headers['X-CSRF-Ts']    = String(csrf.ts);
      }
    }
    const r = await fetch(API_URL, {
      method: 'POST',
      headers,
      // credentials: 'include' SUPPRIMÉ — correction audit C-03 / C-02
      // L'auth repose sur X-Auth-Token (header custom), pas sur des cookies.
      // Supprimer credentials empêche le vecteur CSRF par cookies.
      body: JSON.stringify(data),
    });
    const text = await r.text();
    // ─── Détection interception hébergeur gratuit ─────────────────────────────
    // InfinityFree / 000WebHost renvoient une page HTML (cookie de tracking)
    // au lieu du JSON attendu. On détecte ce cas pour permettre le retry dans joinChat.
    if (text && text.trimStart().startsWith('<')) {
      return { _htmlIntercepted: true };
    }
    return JSON.parse(text);
  } catch (e) {
    if (e?.name !== 'AbortError') setOnlineStatus(false);
    return e?.name === 'AbortError' ? { _aborted: true } : null;
  }
}

// NOTE : on utilise POST au lieu de GET pour éviter que les hébergeurs gratuits
// (InfinityFree, etc.) ne réécrivent ou tronquent les paramètres de l'URL (?i=1).
// SÉCURITÉ (audit #8) : apiGet() est UNIQUEMENT pour les endpoints publics sans authentification
// (actuellement : pseudo_probe). Pour tout endpoint nécessitant une session, utiliser apiGetAuth().
// Ne jamais ajouter un appel apiGet() pour une action authentifiée — le token serait absent
// des headers et tomberait sur le fallback body (supprimé côté serveur — renverra 401).
async function apiGet(params) {
  try {
    const r = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      // credentials: 'include' SUPPRIMÉ — correction audit C-03
      body: JSON.stringify(params),
    });
    const text = await r.text();
    // Détection interception hébergeur (HTML au lieu de JSON)
    if (text && text.trimStart().startsWith('<')) return { _htmlIntercepted: true };
    return JSON.parse(text);
  } catch (e) {
    setOnlineStatus(false);
    return null;
  }
}

/**
 * Variante de apiGet qui envoie le token d'authentification dans les headers HTTP
 * (X-Auth-Token, X-User-Id) plutôt que dans l'URL, pour éviter qu'il apparaisse
 * dans les logs serveur et l'historique du navigateur.
 */
async function apiGetAuth(params) {
  try {
    const r = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Auth-Token': myToken || '',
        'X-User-Id':   me?.id  || '',
      },
      // credentials: 'include' SUPPRIMÉ — correction audit C-03
      body: JSON.stringify(params),
    });
    const text = await r.text();
    return JSON.parse(text);
  } catch (e) {
    setOnlineStatus(false);
    return null;
  }
}

// ─── POLLING ────────────────────────────────────────────────────────────────
function startPolling() {
  if (pollTimer) return;
  poll();
  // Correction audit M-06 : intervalle adaptatif (recalculé à chaque démarrage du poll)
  pollTimer = setInterval(poll, getAdaptiveInterval(BASE_POLL_INTERVAL));
}

function stopPolling() {
  clearInterval(pollTimer);
  pollTimer = null;
}

async function poll() {
  if (!me) { stopPolling(); return; }

  // Le token transite dans les headers HTTP (X-Auth-Token / X-User-Id)
  // et non dans l'URL, pour éviter les logs serveur et l'historique navigateur.
  const res = await apiGetAuth({ action: 'poll', since: lastEventTs, room: me.room });
  if (!res) return;

  // ─── Isolation salons : si la présence a expiré côté serveur (403), déclencher
  // un re-join silencieux pour ré-inscrire la présence avant le prochain poll.
  // Le serveur refuse le poll tant que l'utilisateur n'est pas dans users.json,
  // ce qui empêche de lire un salon arbitraire avec un token orphelin.
  if (res.error && (res.error.includes('re-join') || res.error.includes('Présence'))) {
    setTimeout(() => { if (me) silentRejoin(); }, 500);
    return;
  }

  setOnlineStatus(true);

  if (res.users) {
    const freshUsers = {};
    res.users.forEach(u => { freshUsers[u.id] = { ...u, lastSeen: Date.now() }; });
    if (me) freshUsers[me.id] = { ...me, lastSeen: Date.now() };

    // Détecter arrivées/départs en comparant avec la liste précédente.
    // Pour éviter les faux départs (coupure réseau d'1 poll), on n'affiche "a quitté"
    // qu'après 2 polls consécutifs sans l'utilisateur.
    // IMPORTANT : les utilisateurs "en attente de confirmation" restent dans users
    // pour que le compteur fonctionne (users = freshUsers écrase sinon).
    if (initialUsersPollDone) {
      for (const id in freshUsers) {
        if (id !== me?.id && !users[id]) {
          delete absentCount[id];
          const u = freshUsers[id];
          const sysMsgJoin = { id: genId(), type: 'sys', text: `${u.avatar} ${u.name} a rejoint le salon.`, room: me.room };
          allMessages.push(sysMsgJoin);
          if (activeChat.type === 'room') { const a = document.getElementById('messagesArea'); const d = document.createElement('div'); d.className = 'sys-msg'; d.textContent = sysMsgJoin.text; a.appendChild(d); a.scrollTop = a.scrollHeight; }
        } else {
          // Réinitialiser si l'utilisateur était en attente et est revenu
          delete absentCount[id];
        }
      }
      for (const id in users) {
        if (id !== me?.id && !freshUsers[id]) {
          absentCount[id] = (absentCount[id] || 0) + 1;
          if (absentCount[id] >= 2) {
            // Confirmé absent 2 polls consécutifs → départ réel
            delete absentCount[id];
            const u = users[id];
            const sysMsgLeave = { id: genId(), type: 'sys', text: `${u.avatar} ${u.name} a quitté le salon.`, room: me.room };
            allMessages.push(sysMsgLeave);
            if (activeChat.type === 'room') { const a = document.getElementById('messagesArea'); const d = document.createElement('div'); d.className = 'sys-msg'; d.textContent = sysMsgLeave.text; a.appendChild(d); a.scrollTop = a.scrollHeight; }
            if (typingUsers[id]) { clearTimeout(typingUsers[id].timeout); delete typingUsers[id]; renderTyping(); }
            // Ne PAS remettre l'utilisateur dans freshUsers : il est parti, on le retire de users
          } else {
            // absentCount === 1 : on garde l'utilisateur dans freshUsers pour confirmer au prochain poll
            freshUsers[id] = users[id];
          }
        }
      }
    }

    if (!freshUsers[BOT_ID]) {
      freshUsers[BOT_ID] = { id:BOT_ID, name:'IA', avatar:'🤖', color:'c-purple', room:me.room, lastSeen:Date.now() };
    }
    users = freshUsers;
    initialUsersPollDone = true;
    updateUsersList();
    // Désactiver les pseudos cliquables des utilisateurs déconnectés dans le DOM
    if (activeChat.type === 'room') {
      document.querySelectorAll('.msg-author-clickable[data-user-id]').forEach(el => {
        if (!users[el.dataset.userId]) {
          el.classList.remove('msg-author-clickable');
          el.removeAttribute('title');
          el.onclick = null;
        }
      });
    }
  }

  if (res.events && res.events.length > 0) {
    for (const ev of res.events) {
      await processEvent(ev);
      if (ev.ts > lastEventTs) lastEventTs = ev.ts;
    }
  }

  if (lastEventTs === 0 && res.serverTime) lastEventTs = res.serverTime;
}

// ─── TRAITEMENT DES ÉVÉNEMENTS ──────────────────────────────────────────────
async function processEvent(ev) {
  const { type, user } = ev;

  if (type === 'delete_image') {
    const idx = allMessages.findIndex(m => m.imageUrl && ev.imageUrl && m.imageUrl === ev.imageUrl);
    if (idx !== -1) {
      allMessages.splice(idx, 1);
      renderMessages();
    }
    return;
  }

  if (!user) return;
  const sameRoom = user.room === me.room;

  if (type === 'join' || type === 'heartbeat') {
    // ─── Correction faille #1 — Import de la clé ECDSA de signature ────────────
    if (ev.signPubKey && user.id !== me.id) {
      importSignPubKey(ev.signPubKey).then(sk => {
        if (sk) signPubKeys[user.id] = sk;
      });
    }
    // Import de la clé publique RSA pour le chiffrement E2E + vérification TOFU
    if (ev.pubKey && user.id !== me.id) {
      importPubKey(ev.pubKey).then(async k => {
        if (k) {
          pubKeys[user.id] = k;
          // ─── Correction audit M-03 : LRU cap à 100 clés ──────────────────────
          // pubKeys croît indéfiniment sans cap — purge les clés hors-session en priorité,
          // puis les plus anciennes si toujours > 100. Protège contre la fuite mémoire
          // sur un salon très actif avec fort turnover.
          const allPkIds = Object.keys(pubKeys);
          if (allPkIds.length > 100) {
            for (const pkId of allPkIds) {
              if (!users[pkId] && pkId !== me?.id && Object.keys(pubKeys).length > 100) {
                delete pubKeys[pkId];
              }
            }
            // Si toujours > 100 (tous en session), supprimer les premiers entrés
            const remaining = Object.keys(pubKeys);
            if (remaining.length > 100) {
              remaining.slice(0, remaining.length - 100).forEach(pkId => { if (pkId !== me?.id) delete pubKeys[pkId]; });
            }
          }
          // Calculer et stocker l'empreinte pour affichage/vérification hors-bande
          const fp = await computeKeyFingerprint(ev.pubKey);
          if (fp) {
            pubKeys[user.id]._fingerprint = fp;
            // Vérification TOFU : alerte si la clé a changé depuis la dernière session
            checkTofuFingerprint(user.id, user.name || user.id, fp);
          }
          updateE2eBadge();
        }
      });
    }
    // Les messages système join/leave sont gérés par le diff de la liste users dans poll()
    return;
  }

  if (type === 'leave') {
    // Nettoyage de l'indicateur de frappe uniquement (le message système est géré par poll())
    if (typingUsers[user.id]) {
      clearTimeout(typingUsers[user.id].timeout);
      delete typingUsers[user.id];
      renderTyping();
    }
    return;
  }

  if (type === 'wizz') {
    if (ev.toId !== me?.id) return; // pas pour moi
    if (blockedUsers.has(user.id)) return; // bloqué
    triggerWizzEffect(user.name);
    showWizzToast(`⚡ ${user.name} vous envoie un Wizz !`, '#f59e0b');
    return;
  }

  if (type === 'typing') {
    if (!sameRoom || user.id === me.id) return;
    if (ev.typing) {
      if (typingUsers[user.id]) clearTimeout(typingUsers[user.id].timeout);
      typingUsers[user.id] = { name: user.name, timeout: setTimeout(() => { delete typingUsers[user.id]; renderTyping(); }, 3500) };
    } else {
      if (typingUsers[user.id]) { clearTimeout(typingUsers[user.id].timeout); delete typingUsers[user.id]; }
    }
    renderTyping();
    return;
  }

  if (type === 'uploading') {
    if (!sameRoom || user.id === me.id) return;
    if (ev.uploading) {
      if (uploadingUsers[user.id]) clearTimeout(uploadingUsers[user.id].timeout);
      // Timeout de sécurité : 30s max si on ne reçoit pas le signal de fin
      uploadingUsers[user.id] = { name: user.name, avatar: user.avatar, timeout: setTimeout(() => { delete uploadingUsers[user.id]; renderTyping(); }, 30000) };
    } else {
      if (uploadingUsers[user.id]) { clearTimeout(uploadingUsers[user.id].timeout); delete uploadingUsers[user.id]; }
    }
    renderTyping();
    return;
  }

  if (type === 'message') {
    const msg = ev.message;
    const isPrivate = !!msg.toId;
    const isForMe = isPrivate && msg.toId === me.id;
    const isGlobal = !isPrivate && sameRoom && user.id !== me.id;

    if (!isForMe && !isGlobal) return;
    if (blockedUsers.has(user.id)) return; // messages d'un bloqué ignorés

    // Éviter les doublons (message déjà chargé via load_history)
    if (allMessages.some(m => m.id === msg.id)) return;

    if (user.id === BOT_ID && typingUsers[BOT_ID]) {
      clearTimeout(typingUsers[BOT_ID].timeout);
      delete typingUsers[BOT_ID];
      renderTyping();
    }

    if (typingUsers[user.id]) {
      clearTimeout(typingUsers[user.id].timeout);
      delete typingUsers[user.id];
      renderTyping();
    }

    let plainText = msg.text || '';
    let wasEncrypted = false;
    if (isPrivate && isEncryptedPayload(plainText)) {
      // Correction audit H-02 : escaper le plaintext déchiffré (non encodé par le serveur).
      plainText = escHtml(await decryptDM(plainText, user.id));
      wasEncrypted = true;
    }
    // Valider l'URL image côté client (anti-XSS si message forgé)
    const imageUrl = (msg.imageUrl && isSafeImageUrl(msg.imageUrl)) ? msg.imageUrl : null;
    const fullMsg = { ...msg, room: user.room, text: plainText, author: user, mine: false, encrypted: wasEncrypted, imageUrl };
    allMessages.push(fullMsg);

    if (isGlobal && activeChat.type === 'room') {
      appendMessage(fullMsg);
    } else if (isForMe && activeChat.type === 'private' && activeChat.id === user.id) {
      appendMessage(fullMsg);
      if (!silencedDMs.has(user.id)) playDmSound();
    } else {
      if (isForMe) { unreadDMs[user.id] = (unreadDMs[user.id]||0) + 1; updateUsersList(); if (!silencedDMs.has(user.id)) playDmSound(); }
      const preview = imageUrl ? '🖼 Image' : `${plainText.slice(0,40)}${plainText.length>40?'…':''}`;
      showToast(`💬 ${user.name} : ${preview}`);
      flashTitle(user.name);
    }
  }
}

// ─── PICKERS ─────────────────────────────────────────────────────────────────
document.querySelectorAll('.avatar-opt').forEach(el => {
  el.onclick = () => { document.querySelectorAll('.avatar-opt').forEach(e => e.classList.remove('selected')); el.classList.add('selected'); };
});
document.querySelectorAll('.color-dot').forEach(el => {
  el.onclick = () => { document.querySelectorAll('.color-dot').forEach(e => e.classList.remove('selected')); el.classList.add('selected'); };
});
document.querySelectorAll('.room-opt').forEach(el => {
  el.onclick = () => { document.querySelectorAll('.room-opt').forEach(e => e.classList.remove('selected')); el.classList.add('selected'); };
});

// ─── PSEUDO CHECK ────────────────────────────────────────────────────────────
let knownNames = new Set();
async function checkPseudoAvailability() {
  // Correction audit #10 : API name-specific (booléen) — plus d'énumération de la liste complète
  const val = document.getElementById('usernameInput').value.trim();
  const warn = document.getElementById('pseudoWarning');
  if (val.length >= 2) {
    const res = await apiGet({ action:'pseudo_probe', name: val }).catch(() => null);
    // Ignorer si l'hébergeur a intercepté la requête (HTML au lieu de JSON)
    if (res?._htmlIntercepted) { warn.classList.remove('show'); return; }
    if (res?.taken) warn.classList.add('show'); else warn.classList.remove('show');
  } else { warn.classList.remove('show'); }
}

// ─── JOIN ────────────────────────────────────────────────────────────────────
async function joinChat() {
  const name = document.getElementById('usernameInput').value.trim();
  if (!name) { showToast('Entrez votre pseudo !'); return; }
  if (name.length < 2) { showToast('Pseudo trop court (2 min)'); return; }

  // Correction audit #10 : vérification name-specific (plus d'énumération de liste)
  const probeRes = await apiGet({ action:'pseudo_probe', name });
  if (probeRes?.taken) {
    document.getElementById('pseudoWarningText').textContent = `"${name}" est déjà utilisé.`;
    document.getElementById('pseudoWarning').classList.add('show');
    return;
  }

  const btn = document.getElementById('joinBtn');
  btn.disabled = true; btn.textContent = 'Connexion…';

  const avatar = document.querySelector('.avatar-opt.selected')?.dataset.av || '😊';
  const color  = document.querySelector('.color-dot.selected')?.dataset.color || 'c-blue';
  const room   = document.querySelector('.room-opt.selected')?.dataset.room || 'Général';

  me = { id:genId(), name, avatar, color, room };

  // ─── Vérification du contexte sécurisé (HTTPS ou localhost) ─────────────────
  // crypto.subtle est undefined en HTTP pur (spec W3C — contexte non sécurisé).
  // Sans cette vérification, le join reste bloqué sur "Génération des clés…"
  // indéfiniment sans aucun message d'erreur.
  if (!window.isSecureContext) {
    btn.disabled = false; btn.textContent = 'Rejoindre le chat →';
    me = null;
    showToast('⚠️ HTTPS requis — les DMs chiffrés nécessitent une connexion sécurisée. Contactez votre administrateur.');
    // Afficher aussi un message visible dans la card de login
    const warn = document.getElementById('pseudoWarning');
    document.getElementById('pseudoWarningText').textContent =
      'Ce site doit être servi en HTTPS pour activer le chiffrement. Accès refusé en HTTP.';
    warn.classList.add('show');
    return;
  }

  // Attendre la clé E2E pré-générée en arrière-plan.
  // Dans la quasi-totalité des cas elle est déjà prête (l'utilisateur a mis
  // plus de temps à remplir le formulaire que les ~300 ms de génération RSA).
  if (!myKeyPair) {
    btn.textContent = 'Génération des clés…';
    try {
      await _cryptoReady;
    } catch (_) {
      // La pré-génération a échoué (timing rare) : on retente une fois.
      try { await initCrypto(); } catch (e) {
        btn.disabled = false; btn.textContent = 'Rejoindre le chat →';
        me = null;
        showToast('Erreur cryptographique — rechargez la page.');
        return;
      }
    }
    // Sécurité : si initCrypto() n'a pas rempli myKeyPair (erreur silencieuse), on retente une fois.
    if (!myKeyPair) {
      try { await initCrypto(); } catch (e) {
        btn.disabled = false; btn.textContent = 'Rejoindre le chat →';
        me = null;
        showToast('Erreur cryptographique — rechargez la page.');
        return;
      }
    }  }

  // ─── Retry automatique pour hébergeurs gratuits (InfinityFree, 000WebHost…) ──
  // Stratégie en 2 phases :
  //  1. Attendre la fin du warmup iframe lancé au chargement de la page
  //     (dans la plupart des cas déjà terminé → 0ms d'attente supplémentaire).
  //  2. Boucle de retry : si l'hébergeur intercepte encore (HTML au lieu de JSON),
  //     on relance une iframe de warmup et on réessaie — tout en silence, sans rechargement.
  const JOIN_MAX_RETRIES = 4;
  const JOIN_RETRY_DELAYS = [800, 1500, 2000, 2500]; // ms entre chaque tentative
  let joinRes = null;

  // Phase 1 : attendre le warmup de démarrage (non bloquant si déjà fini)
  if (_warmupPromise) {
    btn.textContent = 'Vérification connexion…';
    await _warmupPromise;
    _warmupPromise = null;
  }

  for (let attempt = 0; attempt <= JOIN_MAX_RETRIES; attempt++) {
    if (attempt > 0) {
      btn.textContent = `Connexion en cours… (${attempt}/${JOIN_MAX_RETRIES})`;
      await warmupFreeHostCookie(JOIN_RETRY_DELAYS[attempt - 1] + 500);
    }
    // ─── Correction M-01 : fetch direct pour lire le header X-Session-Token ────
    // apiPost() consomme r.text() et perd la réponse. On fait le fetch manuellement
    // pour récupérer le token depuis le header HTTP (jamais loggé par les proxies).
    try {
      const rawResp = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'join', action: 'join', user: me, pubKey: myPubKeyB64, signPubKey: mySignPubKeyB64 }),
      });
      const text = await rawResp.text();
      if (text && text.trimStart().startsWith('<')) {
        joinRes = { _htmlIntercepted: true };
      } else {
        joinRes = JSON.parse(text);
        // Préférer le header HTTP (moins exposé dans les logs proxy), fallback body
        const headerToken = rawResp.headers.get('X-Session-Token');
        if (headerToken && /^[0-9a-f]{64}$/.test(headerToken)) {
          joinRes._token = headerToken;
        }
        // Mémoriser le code HTTP pour distinguer les erreurs serveur définitives
        joinRes._status = rawResp.status;
      }
    } catch (e) {
      setOnlineStatus(false);
      joinRes = null;
    }
    if (joinRes?._token || joinRes?.token) break;
    if (joinRes?._htmlIntercepted) {
      if (attempt === 0) btn.textContent = 'Initialisation hébergeur…';
      continue;
    }
    if (joinRes === null) continue;
    // Erreur serveur définitive (4xx) : inutile de retenter, on sort immédiatement
    if (joinRes._status >= 400 && joinRes._status < 500) break;
    break;
  }
  // Résoudre le token : header HTTP en priorité, puis corps JSON (compatibilité)
  const resolvedToken = joinRes?._token || joinRes?.token;
  if (!resolvedToken) {
    btn.disabled = false; btn.textContent = 'Rejoindre le chat →'; me = null;
    // ─── Affichage contextuel selon la cause de l'échec ───────────────────────
    if (joinRes?._htmlIntercepted) {
      showToast("❌ Connexion impossible. Essayez d'ouvrir api.php dans un nouvel onglet, puis revenez.");
    } else if (joinRes?._status === 409 || joinRes?.error?.toLowerCase().includes('pseudo')) {
      // Pseudo déjà pris : afficher l'avertissement inline sous le champ, pas un toast générique
      const warnEl = document.getElementById('pseudoWarning');
      const warnTxt = document.getElementById('pseudoWarningText');
      if (warnTxt) warnTxt.textContent = joinRes.error || 'Ce pseudo est déjà utilisé.';
      if (warnEl) warnEl.classList.add('show');
      document.getElementById('usernameInput')?.focus();
    } else if (joinRes?.error) {
      showToast('❌ ' + joinRes.error);
    } else {
      showToast('❌ Impossible de se connecter au serveur.');
    }
    return;
  }

  // Stocker le token de session ET l'userId serveur en mémoire (jamais localStorage)
  // Le token est lu depuis le header X-Session-Token (moins exposé dans les logs proxy).
  myToken = resolvedToken;
  if (joinRes.userId) {
    me.id = joinRes.userId; // Remplace l'ID local généré par genId() par l'ID serveur
  }

  btn.disabled = false; btn.textContent = 'Rejoindre le chat →';
  heartbeatInterval = setInterval(async () => {
    if (!me || !myToken) return;
    const res = await apiPost({ type:'heartbeat', action:'heartbeat', user:me, pubKey: myPubKeyB64, signPubKey: mySignPubKeyB64 });
    if (res && (res.error || res.status === 401)) {
      setTimeout(() => { if (me) silentRejoin(); }, 4000);
    }
    // ─── Rotation silencieuse du token ───────────────────────────────────────
    if (res?.newToken && typeof res.newToken === 'string' && /^[0-9a-f]{64}$/.test(res.newToken)) {
      myToken = res.newToken;
      _csrfToken     = null;
      _csrfExpiresAt = 0;
    }
    // ─── Nonce beacon : mis à jour à chaque heartbeat ─────────────────────────
    if (res?.beaconNonce && typeof res.beaconNonce === 'string' && /^[0-9a-f]{64}$/.test(res.beaconNonce)) {
      myBeaconNonce = res.beaconNonce;
    }
  }, getAdaptiveInterval(BASE_HEARTBEAT_INTERVAL));

  lastEventTs = 0;
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('app').classList.add('visible');
  updateRoomUI();

  users[BOT_ID] = { id:BOT_ID, name:'IA', avatar:'🤖', color:'c-purple', room:me.room, lastSeen:Date.now() };
  document.getElementById('joinedMsg').textContent = `Bienvenue, ${name} ! Vous avez rejoint ${room}.`;
  document.getElementById('msgInput').focus();
  setOnlineStatus(true);

  // Charger l'historique EN PREMIER — le poll démarre seulement après,
  // avec lastEventTs déjà calé sur serverTime (pas de doublons possible)

  // ─── Correction audit M-04 : avertissement clé E2E ───────────────────────
  // La clé privée RSA est générée en mémoire à chaque session.
  // Les DMs chiffrés des sessions précédentes sont donc illisibles.
  const e2eWarning = document.createElement('div');
  e2eWarning.className = 'sys-msg';
  e2eWarning.textContent = '🔒 Nouvelle clé E2E générée — les messages chiffrés des sessions précédentes ne sont plus lisibles.';
  document.getElementById('messagesArea').appendChild(e2eWarning);

  await loadHistory();
  startPolling();

  window.addEventListener('beforeunload', () => leaveChat());
  window.addEventListener('keydown', e => { if (e.key==='Escape') toggleEmoji(true); });
}

// ─── CHARGEMENT HISTORIQUE ───────────────────────────────────────────────────
async function loadHistory() {
  if (!me) return;
  const res = await apiGetAuth({ action: 'load_history', room: me.room, limit: 50 });
  if (!res || !res.history) return;

  // Construire un Set des IDs déjà présents pour le dédoublonnage O(1)
  const existingIds = new Set(allMessages.map(m => m.id).filter(Boolean));

  for (const ev of res.history) {
    if (ev.type !== 'message') continue;
    const msg     = ev.message ?? {};
    const user    = ev.user    ?? {};

    // Ne pas ajouter un message déjà dans allMessages (silentRejoin peut appeler loadHistory plusieurs fois)
    if (msg.id && existingIds.has(msg.id)) continue;

    const isMine  = user.id === me.id;
    const isPriv  = !!msg.toId;

    let plainText = msg.text || '';
    let wasEncrypted = false;
    if (isPriv && isEncryptedPayload(plainText)) {
      // Correction audit H-02 : escaper le plaintext déchiffré (non encodé par le serveur)
      plainText    = escHtml(await decryptDM(plainText));
      wasEncrypted = true;
    }

    const imageUrl = (msg.imageUrl && isSafeImageUrl(msg.imageUrl)) ? msg.imageUrl : null;
    const fullMsg  = {
      ...msg,
      room      : user.room,
      text      : plainText,
      author    : user,
      mine      : isMine,
      encrypted : wasEncrypted,
      imageUrl,
    };
    allMessages.push(fullMsg);
    existingIds.add(msg.id);
  }

  if (res.serverTime) lastEventTs = res.serverTime;

  renderMessages();
}

// ─── RÉ-INSCRIPTION SILENCIEUSE ──────────────────────────────────────────────
/**
 * Tente de ré-inscrire la présence côté serveur sans interrompre l'UI.
 * Utilisé quand le heartbeat retourne une erreur (présence expirée après coupure réseau).
 * - Si la session est encore valide (dans sessions.json) : le serveur accepte le heartbeat
 *   et ré-inscrit la présence automatiquement (logique côté PHP).
 * - Si la session a aussi expiré : on tente un join complet avec le même token,
 *   ce qui régénère la présence et affiche un toast discret à l'utilisateur.
 */
let _silentRejoinInProgress = false;
let _lastSilentRejoin = 0;
async function silentRejoin() {
  const now = Date.now();
  // Cooldown de 15s entre deux exécutions successives (le guard _inProgress ne couvre que la concurrence)
  if (_silentRejoinInProgress || !me || (now - _lastSilentRejoin) < 15000) return;
  _silentRejoinInProgress = true;
  _lastSilentRejoin = now;
  try {
    const res = await apiPost({ type:'join', action:'join', user:me, pubKey: myPubKeyB64, signPubKey: mySignPubKeyB64 });
    if (res?.token) {
      myToken = res.token;
      // L'userId ne change pas lors d'un re-join silencieux : le serveur reconnaît
      // le token existant et retourne le même userId. On le réaffirme par précaution.
      if (res.userId && me) me.id = res.userId;
      showToast('🔄 Reconnexion automatique effectuée');
    }
    await loadHistory();
  } catch (_) {
  } finally {
    _silentRejoinInProgress = false;
  }
}

// ─── LEAVE ───────────────────────────────────────────────────────────────────
function leaveChat() {
  if (me && myToken) {
    // fetch() avec keepalive:true est l'équivalent moderne de sendBeacon — il survit à la
    // fermeture de la page et supporte les headers custom (contrairement à sendBeacon).
    // Le token transite donc dans X-Auth-Token (jamais dans le body, jamais loggé).
    // Limite : keepalive est ignoré si la taille totale des requêtes en vol dépasse ~64 Ko
    // (spécification Fetch) — ce payload de quelques octets est largement en dessous.
    // Fallback : si fetch/keepalive n'est pas disponible (navigateur très ancien),
    // on envoie un sendBeacon SANS token — le serveur refusera le leave (401) mais
    // la session expirera naturellement via SESSION_TTL (2h). C'est acceptable.
    const payload = JSON.stringify({ type:'leave', action:'leave', user:me });
    let sent = false;
    try {
      if (typeof fetch !== 'undefined') {
        fetch(API_URL, {
          method:    'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Auth-Token': myToken,
            'X-User-Id':    me.id,
          },
          body:      payload,
          keepalive: true,
        });
        sent = true;
      }
    } catch(_) { /* fetch indisponible ou bloqué */ }

    if (!sent && typeof navigator.sendBeacon === 'function') {
      // ─── Correction : nonce HMAC en priorité, token brut en fallback ─────────
      // Le nonce est fourni par le dernier heartbeat — il ne contient pas le token
      // de session et n'expose rien d'utile si un WAF/middleware log le body.
      // Fallback sur _beaconToken uniquement si aucun nonce disponible (1ère déco
      // avant le 1er heartbeat, cas très rare sur navigateurs anciens sans keepalive).
      const beaconPayload = myBeaconNonce
        ? JSON.stringify({ type: 'leave', action: 'leave', user: me,
            _beaconNonce: myBeaconNonce, _beaconUserId: me.id })
        : JSON.stringify({ type: 'leave', action: 'leave', user: me,
            _beaconToken: myToken, _beaconUserId: me.id });
      navigator.sendBeacon(API_URL, new Blob([beaconPayload], { type: 'application/json' }));
    }
  }
  clearInterval(heartbeatInterval); stopPolling();
  me = null; users = {}; typingUsers = {}; uploadingUsers = {}; allMessages = []; unreadDMs = {}; silencedDMs.clear(); initialUsersPollDone = false;
  Object.keys(absentCount).forEach(k => delete absentCount[k]);
  _lastSilentRejoin = 0;
  activeChat = { type:'room', id:null }; lastAuthorId = null; isTyping = false; lastEventTs = 0;
  myKeyPair = null; myPubKeyB64 = null; mySignKeyPair = null; mySignPubKeyB64 = null; myToken = null; myBeaconNonce = null; Object.keys(pubKeys).forEach(k => delete pubKeys[k]); Object.keys(signPubKeys).forEach(k => delete signPubKeys[k]); Object.keys(botHistory).forEach(k => delete botHistory[k]);

  document.getElementById('messagesArea').innerHTML = '<div class="date-divider">Aujourd\'hui</div><div class="sys-msg" id="joinedMsg"></div>';
  document.getElementById('usersList').innerHTML = '';
  document.getElementById('typingBar').innerHTML = '';
  document.getElementById('msgInput').value = '';

  document.getElementById('app').classList.remove('visible');
  document.getElementById('loginScreen').style.display = 'flex';
}

// ─── SEND ────────────────────────────────────────────────────────────────────
function handleKey(e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }

function handleTyping() {
  const input = document.getElementById('msgInput');
  input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px';

  if (!isTyping) { isTyping = true; apiPost({ type:'typing', action:'typing', user:me, typing:true }); }
  clearTimeout(typingBroadcastTimeout);
  typingBroadcastTimeout = setTimeout(() => { isTyping = false; apiPost({ type:'typing', action:'typing', user:me, typing:false }); }, 2500);
}

// ═══════════════════════════════════════════════════════════════════════════
// ANTI-FLOOD — Gestionnaire côté client
// ═══════════════════════════════════════════════════════════════════════════
// Logique : token bucket à fenêtre glissante avec 3 niveaux d'alerte.
//
// Paramètres (salon) : 5 tokens max, rechargement 1 token / 1000 ms
// Paramètres (DM)    : 8 tokens max, rechargement 1 token / 1250 ms
// Ces valeurs sont alignées avec les rate-limits serveur (flood_room_ / flood_dm_).
//
// En plus : délai minimum entre deux envois (FLOOD_MIN_DELAY), et détection
// de répétition (FLOOD_MAX_REPEAT messages identiques consécutifs).
// ═══════════════════════════════════════════════════════════════════════════

const FLOOD = {
  // ── Paramètres salon ──
  ROOM_TOKENS    : 5,       // tokens disponibles pour le salon
  ROOM_REGEN_MS  : 1000,    // 1 token régénéré toutes les 1000 ms
  // ── Paramètres DM ──
  DM_TOKENS      : 8,
  DM_REGEN_MS    : 1250,    // DM un peu plus généreux que le salon
  // ── Partagés ──
  MIN_DELAY_MS   : 400,     // délai minimal entre deux envois (ms)
  MAX_REPEAT     : 3,       // nombre max de fois qu'on peut envoyer le même texte consécutivement
  BLOCK_SECS     : 5,       // durée de blocage total quand les tokens tombent à 0
};

const _flood = {
  // Tokens courants (float pour interpolation)
  roomTokens   : FLOOD.ROOM_TOKENS,
  dmTokens     : FLOOD.DM_TOKENS,
  // Timestamp du dernier envoi
  lastSendTime : 0,
  // Dernier texte envoyé (pour la détection de répétition)
  lastText     : '',
  repeatCount  : 0,
  // Blocage total (après épuisement des tokens)
  blockedUntil : 0,
  // Timers internes
  _regenTimer  : null,
  _countdownTimer: null,
};

/** Démarre la régénération de tokens si elle n'est pas déjà en cours. */
function _floodStartRegen() {
  if (_flood._regenTimer) return;
  _flood._regenTimer = setInterval(() => {
    const isDM = activeChat.type === 'private';
    if (isDM) {
      _flood.dmTokens   = Math.min(FLOOD.DM_TOKENS,   _flood.dmTokens   + 1);
    } else {
      _flood.roomTokens = Math.min(FLOOD.ROOM_TOKENS,  _flood.roomTokens + 1);
    }
    _floodUpdateUI();
    // Arrêter le timer si tous les tokens sont pleins
    if (_flood.roomTokens >= FLOOD.ROOM_TOKENS && _flood.dmTokens >= FLOOD.DM_TOKENS) {
      clearInterval(_flood._regenTimer);
      _flood._regenTimer = null;
    }
  }, Math.min(FLOOD.ROOM_REGEN_MS, FLOOD.DM_REGEN_MS));
}

/**
 * Vérifie si l'envoi est autorisé.
 * @param {string} text — texte brut à envoyer
 * @returns {{ ok: boolean, reason?: string, blockedForMs?: number }}
 */
function floodCheck(text) {
  const now  = Date.now();
  const isDM = activeChat.type === 'private';

  // 1. Blocage total actif ?
  if (now < _flood.blockedUntil) {
    return { ok: false, reason: 'flood', blockedForMs: _flood.blockedUntil - now };
  }

  // 2. Délai minimum entre envois
  if (now - _flood.lastSendTime < FLOOD.MIN_DELAY_MS) {
    return { ok: false, reason: 'cooldown', blockedForMs: FLOOD.MIN_DELAY_MS - (now - _flood.lastSendTime) };
  }

  // 3. Répétition de message identique
  const normalized = text.trim().toLowerCase();
  if (normalized === _flood.lastText && normalized.length > 0) {
    _flood.repeatCount++;
    if (_flood.repeatCount >= FLOOD.MAX_REPEAT) {
      _flood.blockedUntil = now + FLOOD.BLOCK_SECS * 1000;
      _floodStartRegen();
      _floodUpdateUI(true);
      return { ok: false, reason: 'repeat', blockedForMs: FLOOD.BLOCK_SECS * 1000 };
    }
  } else {
    _flood.repeatCount = 0;
    _flood.lastText = normalized;
  }

  // 4. Token disponible ?
  const tokens  = isDM ? _flood.dmTokens   : _flood.roomTokens;
  if (tokens <= 0) {
    _flood.blockedUntil = now + FLOOD.BLOCK_SECS * 1000;
    _floodStartRegen();
    _floodUpdateUI(true);
    return { ok: false, reason: 'flood', blockedForMs: FLOOD.BLOCK_SECS * 1000 };
  }

  return { ok: true };
}

/**
 * Consomme un token après un envoi réussi.
 */
function floodConsume() {
  const isDM = activeChat.type === 'private';
  _flood.lastSendTime = Date.now();
  if (isDM) {
    _flood.dmTokens   = Math.max(0, _flood.dmTokens   - 1);
  } else {
    _flood.roomTokens = Math.max(0, _flood.roomTokens - 1);
  }
  _floodStartRegen();
  _floodUpdateUI();
}

/**
 * Met à jour la barre de tokens et l'état du bouton.
 * @param {boolean} [blocked] — forcer l'affichage de blocage
 */
function _floodUpdateUI(blocked = false) {
  const isDM       = activeChat.type === 'private';
  const maxTokens  = isDM ? FLOOD.DM_TOKENS   : FLOOD.ROOM_TOKENS;
  const curTokens  = isDM ? _flood.dmTokens   : _flood.roomTokens;
  const bar        = document.getElementById('floodBar');
  const btn        = document.getElementById('sendBtn');
  const warn       = document.getElementById('floodWarning');
  if (!bar || !btn || !warn) return;

  // Construire les tokens visuels si pas encore fait ou si maxTokens a changé
  if (bar.children.length !== maxTokens) {
    bar.innerHTML = '';
    for (let i = 0; i < maxTokens; i++) {
      const dot = document.createElement('span');
      dot.className = 'flood-token';
      bar.appendChild(dot);
    }
  }

  // Colorier les dots
  Array.from(bar.children).forEach((dot, i) => {
    dot.classList.toggle('used', i >= curTokens);
  });

  // Niveau d'alerte : ok / warn / danger
  const ratio = curTokens / maxTokens;
  bar.classList.toggle('visible', curTokens < maxTokens || blocked);
  bar.classList.toggle('warn',    ratio <= 0.6 && ratio > 0.2);
  bar.classList.toggle('danger',  ratio <= 0.2 || blocked);

  // État du bouton
  const now      = Date.now();
  const isBlocked = blocked || now < _flood.blockedUntil;
  btn.classList.toggle('flooded', isBlocked);
  btn.disabled = isBlocked;

  // Message de warning + countdown
  if (isBlocked) {
    const remainMs = Math.max(0, _flood.blockedUntil - now);
    const remainS  = Math.ceil(remainMs / 1000);
    const reasonMsg = _flood.repeatCount >= FLOOD.MAX_REPEAT
      ? `🚫 Message répété — attends ${remainS}s`
      : `⚡ Trop vite ! — attends ${remainS}s`;
    warn.textContent = reasonMsg;
    warn.classList.add('visible');
    btn.innerHTML = `<span class="flood-countdown">${remainS}s</span>`;

    // Countdown en temps réel
    clearInterval(_flood._countdownTimer);
    _flood._countdownTimer = setInterval(() => {
      const rem = Math.max(0, _flood.blockedUntil - Date.now());
      const s   = Math.ceil(rem / 1000);
      btn.innerHTML = rem > 0
        ? `<span class="flood-countdown">${s}s</span>`
        : `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`;
      if (rem <= 0) {
        clearInterval(_flood._countdownTimer);
        btn.classList.remove('flooded');
        btn.disabled = false;
        warn.classList.remove('visible');
        bar.classList.remove('danger');
      } else {
        warn.textContent = _flood.repeatCount >= FLOOD.MAX_REPEAT
          ? `🚫 Message répété — attends ${s}s`
          : `⚡ Trop vite ! — attends ${s}s`;
      }
    }, 250);
  } else {
    // Pas bloqué — icône normale et pas de message
    warn.classList.remove('visible');
    if (!btn.querySelector('svg')) {
      btn.innerHTML = `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`;
    }
  }
}

/** Réinitialise les tokens de la barre quand on change de contexte (salon ↔ DM). */
function floodResetUI() {
  _floodUpdateUI(Date.now() < _flood.blockedUntil);
}

async function sendMessage() {
  const input = document.getElementById('msgInput');
  const text = input.value.trim();
  if (!text) return;

  // ─── Vérification anti-flood côté client ─────────────────────────────────
  const floodResult = floodCheck(text);
  if (!floodResult.ok) {
    // Feedback visuel déjà mis à jour par floodCheck → juste secouer légèrement l'input
    input.style.transition = 'transform 0.1s ease';
    input.style.transform  = 'translateX(4px)';
    setTimeout(() => { input.style.transform = ''; }, 100);
    setTimeout(() => { input.style.transform = 'translateX(-3px)'; }, 120);
    setTimeout(() => { input.style.transform = ''; input.style.transition = ''; }, 220);
    return;
  }

  const isPrivate = activeChat.type === 'private';
  const msgBase = { id:genId(), time:getTime(), toId: isPrivate ? activeChat.id : null };

  const isIaPublicCall = !isPrivate && /^@IA\b/i.test(text);
  const isIaDmCall     = isPrivate && activeChat.id === BOT_ID;

  // Chiffrement E2E si DM et clé disponible
  let textToSend = text;
  let encrypted  = false;
  if (isPrivate && activeChat.id !== BOT_ID && pubKeys[activeChat.id]) {
    try {
      textToSend = await encryptDM(text, pubKeys[activeChat.id]);
      encrypted  = true;
    } catch { /* fallback texte clair */ }
  } else if (isPrivate && activeChat.id !== BOT_ID && !pubKeys[activeChat.id]) {
    showToast('⏳ Clé publique non reçue, message non chiffré.');
  }

  // Correction audit H-02 : escaper le texte clair côté client (messages locaux non passés par le serveur).
  // Le serveur encode via htmlspecialchars ; les messages locaux doivent l'être ici.
  const fullMsg = { ...msgBase, text: escHtml(text), author:me, mine:true, encrypted };
  allMessages.push(fullMsg); appendMessage(fullMsg);

  // Consommer un token anti-flood dès l'envoi (avant même la réponse serveur)
  floodConsume();

  const sendRes = await apiPost({ type:'message', action:'send', user:me, message:{ ...msgBase, text: textToSend } });

  if (!sendRes?.ok) {
    // Annulation navigateur (DevTools switch, reload…) : ne pas supprimer le message,
    // juste ignorer silencieusement — la requête a peut-être quand même abouti.
    if (sendRes?._aborted) return;
    // Le serveur a refusé — retirer le message de l'état local et prévenir l'utilisateur
    const idx = allMessages.findIndex(m => m.id === msgBase.id);
    if (idx !== -1) allMessages.splice(idx, 1);
    // Retirer la bulle du DOM
    const bubbles = document.querySelectorAll('.msg-row.mine');
    for (const row of Array.from(bubbles).reverse()) {
      if (row.dataset.msgId === msgBase.id) { row.remove(); break; }
    }
    showToast('❌ Message non envoyé — reconnexion en cours…');
    await silentRejoin();
    return;
  }

  // ─── Appeler le bot UNIQUEMENT si l'envoi a réussi ──────────────────────────
  // Déplacé après le check sendRes.ok pour éviter deux problèmes lors d'une
  // reconnexion automatique :
  // 1. Un faux message « ⚠️ Je ne suis pas disponible » affiché alors que le
  //    réseau était juste momentanément instable.
  // 2. Un silentRejoin() supplémentaire (déclenché par l'échec de bot_ask) qui
  //    s'enchaînait sur celui déjà en cours, bloquant la reprise du fil de DM.
  if (isIaDmCall || isIaPublicCall) {
    const botPrompt = isIaPublicCall ? text.replace(/^@IA\s*/i, '').trim() : text;
    askBotAndDisplay(botPrompt, isIaDmCall ? me.id : null);
  }

  clearTimeout(typingBroadcastTimeout); isTyping = false;
  apiPost({ type:'typing', action:'typing', user:me, typing:false });

  input.value = ''; input.style.height = 'auto';
  document.getElementById('emojiPicker').classList.remove('open');
}

// ─── BOT IA : appel authentifié → gen.pollinations.ai (nouveau, POST, CORS ok) ─
// Clé et modèle Pollinations déplacés côté serveur (api.php) — supprimés ici pour ne plus les exposer au client.

async function askBotAndDisplay(prompt, replyToId, imageUrl = null) {
  if (!prompt && !imageUrl) return;
  // Correction audit #4 : consentement RGPD obligatoire si une image est envoyée au bot tiers
  if (imageUrl) {
    const consented = await requestBotImageConsent();
    if (!consented) return;
  }

  const ctxKey = replyToId ? me.id : 'room';
  if (!botHistory[ctxKey]) botHistory[ctxKey] = [];

  if (typingUsers[BOT_ID]) clearTimeout(typingUsers[BOT_ID].timeout);
  typingUsers[BOT_ID] = {
    name: 'IA',
    timeout: setTimeout(() => { delete typingUsers[BOT_ID]; renderTyping(); }, 30000)
  };
  renderTyping();

  const botUser = { id:BOT_ID, name:'IA', avatar:'🤖', color:'c-purple', room: me?.room };

  // Texte à mémoriser dans l'historique (toujours une chaîne)
  const textContent = prompt ? prompt.trim() : 'Décris cette image.';

  // Ajouter le message utilisateur à l'historique (texte uniquement)
  botHistory[ctxKey].push({ role: 'user', content: textContent });
  if (botHistory[ctxKey].length > BOT_HISTORY_MAX * 2) {
    botHistory[ctxKey].splice(0, botHistory[ctxKey].length - BOT_HISTORY_MAX * 2);
  }

  // Extraire l'imageId depuis l'URL relative (api.php?action=get_image&id=<hex>)
  let imageId = null;
  if (imageUrl) {
    const match = imageUrl.match(/[?&]id=([a-f0-9]+)/);
    if (match) imageId = match[1];
  }

  // Déléguer l'appel Pollinations ET la persistance au serveur via bot_ask
  // → le serveur maintient son propre historique (bot_sessions.json) ; le client
  //   envoie uniquement le dernier message pour éviter le prompt injection via history.
  let responseText = '';
  let serverMsgId  = null;
  try {
    const res = await apiPost({
      action:  'bot_ask',
      prompt:  textContent,          // dernier message uniquement
      imageId: imageId || undefined,
      toId:    replyToId || undefined,
    });
    if (res?.text)  responseText = res.text.trim();
    if (res?.msgId) serverMsgId  = res.msgId; // ID attribué côté serveur
  } catch (_) { /* timeout ou erreur réseau */ }

  if (typingUsers[BOT_ID]) {
    clearTimeout(typingUsers[BOT_ID].timeout);
    delete typingUsers[BOT_ID];
    renderTyping();
  }

  if (!responseText) responseText = '⚠️ Je ne suis pas disponible pour le moment.';

  botHistory[ctxKey].push({ role: 'assistant', content: responseText });

  // Correction H-02 : escaper le texte bot retourné par bot_ask (chemin direct, pas via poll).
  // Le serveur retourne le texte brut dans res.text pour affichage immédiat ; la version
  // htmlspecialchars() est dans events.json pour les autres clients via poll.
  // On l'escaping ici pour que formatMsg() (qui n'encode plus) reste cohérent.
  const safeResponseText = escHtml(responseText);
  const botMsg = { id: serverMsgId || genId(), time: getTime(), text: safeResponseText, author: botUser, mine: false, toId: replyToId };
  allMessages.push(botMsg);

  if (activeChat.type === 'private' && activeChat.id === BOT_ID) appendMessage(botMsg);
  else if (activeChat.type === 'room' && !replyToId) appendMessage(botMsg);
}

// ─── IMAGE UPLOAD ────────────────────────────────────────────────────────────
function formatSpeed(bytesPerSec) {
  if (bytesPerSec >= 1024 * 1024) return (bytesPerSec / (1024 * 1024)).toFixed(1) + ' Mo/s';
  if (bytesPerSec >= 1024)        return (bytesPerSec / 1024).toFixed(0) + ' Ko/s';
  return bytesPerSec + ' o/s';
}
function formatSize(bytes) {
  if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' Mo';
  if (bytes >= 1024)        return (bytes / 1024).toFixed(0) + ' Ko';
  return bytes + ' o';
}

async function onImageSelected(input) {
  const file = input.files[0];
  input.value = '';
  if (!file) return;

  const maxSize = 5 * 1024 * 1024;
  if (file.size > maxSize)                                              { showToast('❌ Image trop lourde (max 5 Mo)'); return; }
  // GIFs exclus : aligné avec le serveur (api.php) qui refuse image/gif délibérément
  // (risque de polyglot GIF/HTML/JS). Accepter le GIF côté client et le rejeter côté serveur
  // causait une erreur cryptique après un upload complet — désormais bloqué des deux côtés.
  if (!['image/jpeg','image/png','image/webp'].includes(file.type)) { showToast('❌ Format non supporté (jpg, png, webp)'); return; }

  const progress  = document.getElementById('uploadProgress');
  const fill      = document.getElementById('uploadFill');
  const label     = document.getElementById('uploadLabel');
  const stats     = document.getElementById('uploadStats');

  // Signaler aux autres que l'upload commence
  apiPost({ type: 'uploading', action: 'uploading', user: me, uploading: true });

  progress.classList.add('show');
  fill.style.width = '0%';
  label.textContent = '📤 Envoi en cours…';
  stats.textContent = '0% · –';

  const formData = new FormData();
  formData.append('action', 'upload_image');
  formData.append('image', file);
  // userId et token envoyés en header (invisibles dans les logs serveur)
  // Le champ multipart a été supprimé : api.php n'accepte plus que les headers.

  // ─── Correction audit C-02 : await doit être hors du callback Promise (non-async) ──
  const csrfUpload = await getCsrfToken();

  const json = await new Promise((resolve) => {
    const xhr = new XMLHttpRequest();
    let startTime    = null;
    let lastLoaded   = 0;
    let lastTime     = null;
    // Lissage exponentiel du débit
    let smoothSpeed  = 0;

    xhr.upload.addEventListener('loadstart', () => {
      startTime = performance.now();
      lastTime  = startTime;
      lastLoaded = 0;
    });

    xhr.upload.addEventListener('progress', (e) => {
      if (!e.lengthComputable) return;

      const now     = performance.now();
      const elapsed = (now - lastTime) / 1000;        // secondes depuis dernier tick
      const delta   = e.loaded - lastLoaded;           // octets depuis dernier tick

      if (elapsed > 0.05) {                            // mettre à jour max 20×/s
        const instantSpeed = delta / elapsed;
        // Lissage exponentiel α=0.3
        smoothSpeed = smoothSpeed === 0 ? instantSpeed : 0.3 * instantSpeed + 0.7 * smoothSpeed;
        lastLoaded = e.loaded;
        lastTime   = now;
      }

      const pct = Math.round((e.loaded / e.total) * 100);
      fill.style.width = pct + '%';
      stats.textContent = `${pct}% · ${formatSpeed(smoothSpeed)} · ${formatSize(e.loaded)} / ${formatSize(e.total)}`;
    });

    xhr.addEventListener('load', () => {
      fill.style.width = '100%';
      label.textContent = '✅ Envoi terminé';
      const totalSec = (performance.now() - startTime) / 1000;
      const avgSpeed = totalSec > 0 ? file.size / totalSec : 0;
      stats.textContent = `100% · moy. ${formatSpeed(avgSpeed)} · ${formatSize(file.size)}`;

      let json = null;
      try { json = JSON.parse(xhr.responseText); } catch(_) {}

      if (!json) {
        showToast('❌ Réponse non-JSON : ' + xhr.responseText.slice(0, 80));
        progress.classList.remove('show'); fill.style.width = '0%';
        resolve(null); return;
      }

      setTimeout(() => { progress.classList.remove('show'); fill.style.width = '0%'; }, 1200);
      resolve(json);
    });

    xhr.addEventListener('error', () => {
      progress.classList.remove('show'); fill.style.width = '0%';
      showToast('❌ Erreur réseau lors de l\'upload');
      apiPost({ type: 'uploading', action: 'uploading', user: me, uploading: false });
      resolve(null);
    });

    xhr.addEventListener('abort', () => {
      progress.classList.remove('show'); fill.style.width = '0%';
      showToast('⚠️ Upload annulé');
      apiPost({ type: 'uploading', action: 'uploading', user: me, uploading: false });
      resolve(null);
    });

    xhr.open('POST', API_URL);
    // xhr.withCredentials = true;  ← SUPPRIMÉ — correction audit C-03
    xhr.setRequestHeader('X-Auth-Token', myToken || '');
    xhr.setRequestHeader('X-User-Id',   me?.id  || '');
    // ─── Correction audit C-02 : headers CSRF (token récupéré avant la Promise, cf. await ci-dessus) ──
    if (csrfUpload.token) {
      xhr.setRequestHeader('X-CSRF-Token', csrfUpload.token);
      xhr.setRequestHeader('X-CSRF-Ts',    String(csrfUpload.ts));
    }
    xhr.send(formData);
  });

  if (!json) return;
  if (!json.ok || !json.imageUrl || !isSafeImageUrl(json.imageUrl)) { showToast('❌ ' + (json.error || 'Erreur upload ou URL invalide')); return; }

  const isPrivate = activeChat.type === 'private';
  const msgBase = {
    id: genId(), time: getTime(),
    toId: isPrivate ? activeChat.id : null,
    imageUrl: json.imageUrl,
    text: '[image]',
  };

  const fullMsg = { ...msgBase, author: me, mine: true };
  allMessages.push(fullMsg);
  appendMessage(fullMsg);

  // Signaler la fin de l'upload
  apiPost({ type: 'uploading', action: 'uploading', user: me, uploading: false });

  await apiPost({ type: 'message', action: 'send', user: me, message: msgBase });

  // Si on est en DM avec le bot, lui soumettre l'image pour analyse visuelle
  // Correction audit #4 : demande de consentement RGPD avant envoi à gen.pollinations.ai
  if (isPrivate && activeChat.id === BOT_ID) {
    const consented = await requestBotImageConsent();
    if (consented) askBotAndDisplay(null, me.id, json.imageUrl);
  }

}

// ─── SUPPRIMER SA PROPRE IMAGE ───────────────────────────────────────────────
async function deleteOwnImage(btn, imageUrl) {
  if (!confirm('Supprimer cette image ? Elle sera retirée pour tout le monde.')) return;

  // Extraire l'id depuis l'URL  api.php?action=get_image&id=XXX
  const match = imageUrl.match(/[?&]id=([a-f0-9]+)/);
  if (!match) { showToast('❌ ID image introuvable'); return; }
  const imageId = match[1];

  btn.disabled = true; btn.textContent = '…';

  // Trouver le msgId dans allMessages
  const msgObj = allMessages.find(m => m.imageUrl === imageUrl && m.mine);
  const msgId  = msgObj?.id || null;

  const res = await apiPost({ action: 'delete_image', imageId, msgId, user: me });

  if (res?.ok) {
    // Retirer localement
    const idx = allMessages.findIndex(m => m.imageUrl === imageUrl && m.mine);
    if (idx !== -1) allMessages.splice(idx, 1);
    // Retirer la bulle du DOM
    const bubble = btn.closest('.bubble');
    const row    = bubble?.closest('.msg-row');
    if (row) row.remove();
    showToast('🗑 Image supprimée');
  } else {
    btn.disabled = false; btn.textContent = '✕';
    showToast('❌ ' + (res?.error || 'Impossible de supprimer'));
  }
}
function openLightbox(src) {
  document.getElementById('lightboxImg').src = src;
  document.getElementById('lightbox').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeLightbox() {
  document.getElementById('lightbox').classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });

// ─── FORCE CHARGEMENT DES IMAGES AU SCROLL ──────────────────────────────────
const imgObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const img = entry.target;
      // Si l'image n'a pas encore de src ou est en erreur, forcer le rechargement
      if (img.dataset.src && img.src !== img.dataset.src) {
        img.src = img.dataset.src;
      }
      imgObserver.unobserve(img);
    }
  });
}, { rootMargin: '200px' });
function setOnlineStatus(online) { apiOnline = online; }

function updateRoomUI() {
  const icon = rooms[me.room] || '💬';
  document.getElementById('sideRoomTag').textContent = me.room;
  if (activeChat.type === 'room') {
    document.getElementById('roomIcon').textContent = icon;
    document.getElementById('roomNameTop').textContent = me.room;
    document.getElementById('dmBackWrap').style.display = 'none';
  } else {
    const u = users[activeChat.id];
    document.getElementById('roomIcon').textContent = u ? u.avatar : '💬';
    document.getElementById('roomNameTop').textContent = u ? `DM · ${u.name}` : 'Message privé';
    document.getElementById('dmBackWrap').style.display = 'flex';
    // Masquer le bouton Wizz si le destinataire est le bot IA
    const wizzBtn = document.getElementById('wizzBtn');
    if (wizzBtn) wizzBtn.style.display = (activeChat.id === BOT_ID) ? 'none' : '';
  }
}

function updateUsersList() {
  const list = document.getElementById('usersList');
  list.innerHTML = '';
  const all = Object.values(users);
  document.getElementById('roomCountTop').textContent = `${all.length} membre${all.length>1?'s':''} en ligne`;
  document.getElementById('onlineCount').textContent = `● ${all.length} en ligne`;

  const activeDmUser = activeChat.type === 'private' ? users[activeChat.id] : null;

  function makeLabel(text) {
    const lbl = document.createElement('div');
    lbl.className = 'section-title';
    lbl.textContent = text;
    return lbl;
  }

  function makeUserItem(u) {
    const isMine = u.id === me?.id;
    const isActiveDm = activeDmUser && u.id === activeDmUser.id;
    const isBlocked = blockedUsers.has(u.id);
    const d = document.createElement('div');
    d.className = `user-item${isMine?' me':''}${isActiveDm?' active-dm':''}${isBlocked?' blocked':''}`;
    if (!isMine) d.dataset.userId = u.id;
    // Défense en profondeur : escHtml() côté client en plus de la sanitisation serveur.
    // Protège contre toute régression ou bypass futur de la sanitisation PHP.
    d.innerHTML = `
      <div class="user-avatar-wrap">
        <div class="user-av ${escHtml(u.color)}">${escHtml(u.avatar)}</div>
        <div class="user-online-dot"></div>
      </div>
      <div class="user-info">
        <div class="user-name">${escHtml(u.name)}${u.id === BOT_ID ? ' <span class="user-ia-tag">Bot</span>' : ''}</div>
        <div class="user-status">${isMine ? 'connecté(e)' : u.id === BOT_ID ? '⚡ Toujours disponible' : escHtml(u.room)}</div>
      </div>
      ${isActiveDm ? '<div class="dm-chat-indicator">live</div>' : ''}
      ${(!isMine && !isActiveDm && (unreadDMs[u.id]||0)>0) ? `<div class="unread-dm-badge">${escHtml(String(unreadDMs[u.id]))}</div>` : ''}`;
    if (!isMine) {
      d.addEventListener('contextmenu', e => openUserCtxMenu(e, u.id));
      d.addEventListener('pointerdown', e => {
        if (e.pointerType === 'touch') {
          const t = setTimeout(() => openUserCtxMenu(e, u.id), 500);
          d.addEventListener('pointerup', () => clearTimeout(t), { once: true });
          d.addEventListener('pointermove', () => clearTimeout(t), { once: true });
        }
      });
    }
    return d;
  }

  // Section "En conversation" si DM actif
  if (activeDmUser) {
    list.appendChild(makeLabel('En conversation'));
    list.appendChild(makeUserItem(activeDmUser));

    const sep = document.createElement('div');
    sep.style.cssText = 'height:1px;background:var(--border);margin:10px 2px 4px;';
    list.appendChild(sep);
  }

  // Section "En ligne"
  list.appendChild(makeLabel('En ligne'));
  all.forEach(u => {
    if (activeDmUser && u.id === activeDmUser.id) return;
    list.appendChild(makeUserItem(u));
  });
}
function addSysMsg(text) {
  const area = document.getElementById('messagesArea');
  const d = document.createElement('div');
  d.className = 'sys-msg'; d.textContent = text;
  area.appendChild(d); area.scrollTop = area.scrollHeight;
}

function appendMessage({ id: fullMsgId, text, time, author, mine, encrypted = false, imageUrl = null }) {
  const area = document.getElementById('messagesArea');
  // Les images affichent toujours le nom (élément visuel distinct)
  const showMeta = imageUrl ? true : lastAuthorId !== author.id;
  lastAuthorId = imageUrl ? null : author.id; // reset après image pour que le msg suivant affiche aussi le nom

  const row = document.createElement('div');
  row.className = `msg-row${mine?' mine':''}`;
  if (mine && fullMsgId) row.dataset.msgId = fullMsgId;

  const av = document.createElement('div');
  av.className = `msg-av${showMeta?' '+author.color:' hidden'}`;
  av.textContent = showMeta ? author.avatar : '';

  const content = document.createElement('div');
  content.className = 'msg-content';

  if (showMeta) {
    const meta = document.createElement('div');
    meta.className = 'msg-meta';
    const authorSpan = document.createElement('span');
    authorSpan.className = 'msg-author';
    authorSpan.textContent = author.name;
    // Clic sur le pseudo → DM (sauf soi-même et utilisateurs déconnectés)
    const isOnline = !!users[author.id];
    if (!mine && author.id !== me?.id && author.name !== me?.name && isOnline) {
      authorSpan.classList.add('msg-author-clickable');
      authorSpan.dataset.userId = author.id;
      authorSpan.title = `Message privé à ${author.name}`;
      authorSpan.onclick = () => openPrivateChat(author.id);
    }
    const timeSpan = document.createElement('span');
    timeSpan.className = 'msg-time';
    timeSpan.textContent = time;
    meta.appendChild(authorSpan);
    meta.appendChild(timeSpan);
    content.appendChild(meta);
  }

  const bubble = document.createElement('div');

  if (imageUrl) {
    // ─── Validation de sécurité : rejeter toute URL non-locale ────────────
    if (!isSafeImageUrl(imageUrl)) {
      bubble.className = 'bubble';
      bubble.innerHTML = '<span class="img-expired">🚫 URL image invalide</span>';
      content.appendChild(bubble); row.appendChild(av); row.appendChild(content);
      area.appendChild(row); area.scrollTop = area.scrollHeight;
      return;
    }
    bubble.className = `bubble image-bubble${mine?' '+author.color:''}`;
    const img = document.createElement('img');
    img.className = 'msg-image';
    img.alt = 'image';
    img.loading = 'eager';
    img.decoding = 'async';
    img.onclick = () => openLightbox(imageUrl);
    img.src = imageUrl;
    img.onerror = () => {
      bubble.innerHTML = '<span class="img-expired">🖼 Image expirée ou introuvable</span>';
    };
    const expiryTag = document.createElement('span');
    expiryTag.className = 'img-expiry-tag';
    expiryTag.textContent = '⏱ Expire dans 24 h';
    bubble.appendChild(img);
    bubble.appendChild(expiryTag);

    // Bouton supprimer (visible seulement pour l'envoyeur)
    if (mine) {
      const msgId = text && text !== '[image]' ? null : (fullMsgId || null);
      const delBtn = document.createElement('button');
      delBtn.className = 'img-delete-btn';
      delBtn.title = 'Supprimer cette image';
      delBtn.innerHTML = '✕';
      delBtn.onclick = (e) => {
        e.stopPropagation();
        deleteOwnImage(delBtn, imageUrl);
      };
      bubble.appendChild(delBtn);
    }
  } else {
    bubble.className = `bubble${mine?' '+author.color:''}${encrypted?' dm-encrypted':''}`;
    bubble.innerHTML = formatMsg(text);
    if (encrypted) {
      const lock = document.createElement('span');
      lock.style.cssText = 'font-size:10px;opacity:0.5;margin-left:6px;user-select:none;';
      lock.textContent = '🔒';
      bubble.appendChild(lock);
    }
  }

  content.appendChild(bubble); row.appendChild(av); row.appendChild(content);
  area.appendChild(row); area.scrollTop = area.scrollHeight;
  if (!mine) flashTitle(author.name);
}

let flashInterval = null, origTitle = 'MyChat';
function flashTitle(name) {
  if (document.hasFocus()) return;
  clearInterval(flashInterval); let on = true;
  flashInterval = setInterval(() => { document.title = on ? `💬 ${name}` : origTitle; on=!on; }, 800);
  window.addEventListener('focus', () => { clearInterval(flashInterval); document.title=origTitle; }, {once:true});
}

function renderTyping() {
  const bar = document.getElementById('typingBar');
  if (activeChat.type !== 'private') { bar.innerHTML = ''; return; }

  // Priorité à l'indicateur d'upload sur l'indicateur de frappe
  const uploading = Object.values(uploadingUsers);
  if (uploading.length) {
    const u = uploading[0];
    bar.innerHTML = `<div class="typing-dots"><span class="t-dot"></span><span class="t-dot"></span><span class="t-dot"></span></div> ${escHtml(u.avatar + ' ' + u.name)} envoie une image…`;
    return;
  }

  const names = Object.values(typingUsers).map(u => u.name);
  if (!names.length) { bar.innerHTML = ''; return; }
  bar.innerHTML = `<div class="typing-dots"><span class="t-dot"></span><span class="t-dot"></span><span class="t-dot"></span></div> ${escHtml(names.join(', '))} ${names.length>1?'écrivent':'écrit'}...`;
}

function openPrivateChat(userId) {
  if (!userId || userId === me?.id) return;
  // Blocage si le destinataire a le même pseudo (cas reconnexion avec un ID différent)
  const targetUser = users[userId];
  if (targetUser && targetUser.name === me?.name) return;
  activeChat = { type:'private', id:userId }; unreadDMs[userId] = 0; silencedDMs.add(userId);
  closeSidebar();
  updateRoomUI(); updateUsersList(); renderMessages(); updateE2eBadge();
  floodResetUI(); // Adapter la barre de tokens au contexte DM
  document.getElementById('msgInput').focus();

  // ─── Récupération immédiate de la clé E2E du destinataire ────────────────────
  // Les clés publiques ne transitent que via les événements join/heartbeat du poll
  // (~1,9 s de cycle). Sans cette récupération proactive, le badge "En attente de clé…"
  // peut rester affiché jusqu'à 4–5 s après l'ouverture du DM.
  // On interroge le nouvel endpoint get_pubkey qui scanne events.json immédiatement.
  if (userId !== BOT_ID && !pubKeys[userId]) {
    fetchPubKeyForUser(userId);
  }
}
function backToRoom() {
  activeChat = { type:'room', id:null };
  updateRoomUI(); updateUsersList(); renderMessages(); updateE2eBadge();
  floodResetUI(); // Adapter la barre de tokens au contexte salon
  document.getElementById('msgInput').focus();
}
function renderMessages() {
  const area = document.getElementById('messagesArea');
  area.innerHTML = '<div class="date-divider">Aujourd\'hui</div>';
  lastAuthorId = null;
  const filtered = allMessages.filter(m => {
    if (m.type === 'sys') return activeChat.type === 'room';
    return activeChat.type==='room' ? (!m.toId && (m.room===me?.room || m.author?.id===me?.id)) : (m.toId && ((m.author?.id===me?.id && m.toId===activeChat.id) || (m.author?.id===activeChat.id && m.toId===me?.id)));
  });
  filtered.forEach(m => {
    if (m.type === 'sys') { addSysMsg(m.text); lastAuthorId = null; return; }
    appendMessage(m);
  });
  // Forcer le navigateur à rendre toutes les images immédiatement
  requestAnimationFrame(() => { area.scrollTop = area.scrollHeight; });
}

// ─── EMOJI PICKER ─────────────────────────────────────────────────────────────
const EP_CATS = [
  // 0 Visages
  ['😊','😂','🤣','😍','🥰','😘','😎','😏','😒','😭','😢','😤','😡','🤬','😱','😨','😰','🤯','😳','🥵','🥶','😶','😐','😑','🤔','🤨','🧐','😬','😴','🥱','🤮','🤧','😷','🤒','🤕','😇','🥳','🤩','😆','😁','😀','😃','😄','😅','😋','😛','😜','🤪','🤑','🤫','🤭','😈','👿','👻','💀','☠️','🤡','👹','👺','💩','🙈','🙉','🙊','😮','😯','😲','😦','😧','🥺','🤥','😪','😏','😶‍🌫️','🫠','🫡','🫢','🫣','🫤','🫨','🤐','😠','😔','😕','🙁','☹️','😣','😖','😞','😟','😓','😩','😫','😤','🥹','🫥','🤓','🧛','🧜','🧚','🧝','🧞','🧟','🧌'],
  // 1 Gestes & Corps
  ['👋','🤚','✋','🖐','👌','🤌','🤏','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','👇','☝️','👍','👎','✊','👊','🤛','🤜','🙌','👏','🤲','🙏','🫶','💪','🦾','🦿','🖕','💅','🤳','🫂','🧠','👀','👁','👅','👂','🦷','🦴','🫁','🫀','❤️‍🔥','💔','🖤','🤍','🤎','💛','💙','💜','🩷','🩵','🩶','🫸','🫷','🫵','🫴','🫳','🫲','🫱','🤙','👐','🤜','🤛','🙅','🙆','💁','🙋','🧏','🙎','🙍','💆','💇','🧖','🛀','🦵','🦶','👃','🫦','🫀','🫁','🦷','🦴','👣'],
  // 2 Animaux
  ['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐨','🐯','🦁','🐮','🐷','🐸','🐵','🙈','🙉','🙊','🐔','🐧','🐦','🐤','🦅','🦆','🦉','🦇','🐺','🐗','🐴','🦄','🐝','🐛','🦋','🐌','🐞','🐜','🪲','🐢','🐍','🦎','🦖','🦕','🐙','🦑','🦐','🦞','🦀','🐡','🐠','🐟','🐬','🐳','🐋','🦈','🐊','🐅','🐆','🦓','🦏','🦛','🦒','🦘','🦬','🐃','🐂','🐄','🦙','🐑','🐏','🐐','🦌','🐕','🐩','🦮','🐕‍🦺','🐈','🐈‍⬛','🦝','🦦','🦥','🦔','🐓','🦃','🦤','🦚','🦜','🦢','🦩','🕊','🐇','🦫','🐁','🐀','🐿','🦔','🪸','🪼','🐾','🌿'],
  // 3 Nourriture
  ['🍕','🍔','🌮','🌯','🥙','🧆','🥚','🍳','🥘','🍲','🥣','🥗','🍿','🧂','🥫','🍱','🍣','🍤','🍙','🍚','🍛','🍜','🍝','🍠','🍢','🍡','🧁','🍰','🎂','🍮','🍭','🍬','🍫','🍩','🍪','🌰','🥜','🍯','🧃','🥤','🧋','🍼','🫖','☕','🍵','🧉','🍶','🍾','🍷','🍸','🍹','🍺','🍻','🥂','🥃','🫗','🍎','🍊','🍋','🍇','🍓','🫐','🍈','🍑','🍒','🍍','🥭','🥝','🍅','🫒','🥑','🌽','🥞','🧇','🥓','🌭','🫔','🧀','🥗','🫕','🥙','🧄','🧅','🥔','🥐','🍞','🥖','🥨','🫓','🍠','🥟','🥠','🥡','🦪','🍦','🍧','🧃','🫙','🥢','🍽','🥄','🍴','🫙','🧊'],
  // 4 Sports & Activités
  ['⚽','🏀','🏈','⚾','🎾','🏐','🏉','🎱','🏓','🏸','🏒','🥊','🥋','🎯','⛳','🎣','🤿','🎽','🎿','🛷','🥌','🎮','🕹','🎲','🎭','🎨','🎬','🎤','🎧','🎼','🎹','🥁','🎷','🎺','🎸','🪕','🎻','🪗','🎪','🤹','🎠','🎡','🎢','🏆','🥇','🥈','🥉','🎖','🎗','🏅','🎫','🎟','🤼','🤸','🏋️','🤺','🤾','⛹️','🧘','🧗','🚵','🚴','🏊','🏄','🛹','🛷','🪃','🏑','🏏','🥅','⛸️','🎣','🤿','🪁','🪃','🏹','🛼','🛶','🧩','🪀','🪆','🎳','🥏','🎰','🎲','♟️','🪅','🪄','🎙','📯','🪘','🪩','🕺','💃','🎭','🎪','🎠','🛝'],
  // 5 Voyages & Lieux
  ['🚀','🛸','✈️','🚂','🚃','🚄','🚅','🚆','🚇','🚈','🚉','🚊','🚋','🚌','🚍','🚎','🚏','🚐','🚑','🚒','🚓','🚔','🚕','🚖','🚗','🚘','🚙','🚚','🛻','🚛','🚜','🛵','🏍','🚲','🛴','🛺','🚁','🚟','⛵','🛶','🚤','🛥','⛴','🛳','🚢','⚓','🗺','🌍','🌎','🌏','🗾','🧭','🏔','⛰','🌋','🗻','🏕','🏖','🏜','🏝','🏞','🏟','🏛','🏗','🧱','🏘','🏚','🏠','🏡','🏢','🏣','🏤','🏥','🌃','🌆','🌇','🌉','🛩','🪂','🪁','🚠','🚡','🛤','🛣','🗽','🗼','🏰','🏯','🕌','🕍','⛪','🛕','🏗','🌁','🌄','🌅','🏙','🌠','🎆','🎇','🗺','🧳','🪝','⛽','🚧','🛂','🛃','🛄','🛅'],
  // 6 Objets
  ['💡','🔦','🕯','🪔','💰','💳','💸','💵','🏧','💎','🔑','🗝','🔐','🔒','🔓','🔨','⚒','🛠','🪛','🔧','🪚','🔩','⚙️','🗜','🔗','⛓','📱','💻','⌨️','🖥','🖨','🖱','🖲','💾','💿','📀','📷','📸','📹','🎥','📽','🎞','📞','☎️','📟','📠','📺','📻','🧭','⏱','⏲','⏰','🕰','⌛','⏳','📡','🔋','🪫','🔌','🪆','🎁','🎀','🎊','🎉','🎈','🎏','🎐','🎑','🧧','📦','📫','📬','📭','📮','🧲','🪤','🪣','🪥','🧸','🪑','🪞','🪟','🪞','🛋','🚪','🪠','🧴','🧹','🧺','🧻','🧼','🪒','🧽','🪜','🪤','🧲','🔭','🔬','🩺','💊','🩹','🩻','🧬','🦽','🦼','🩼','🩺','🪖','🛡','🧰','🗃','🗂','📁','📂','🗃','📋','📌','📍','🖇','📎','✂️','🗃','🗑','✒️','🖊','🖋','✏️','📝','🖍'],
  // 7 Nature & Météo
  ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','❤️‍🔥','💔','✨','⭐','🌟','💫','⚡','🌈','☀️','🌤','⛅','🌥','☁️','🌦','🌧','⛈','🌩','🌨','❄️','☃️','⛄','🌬','💨','🌀','🌊','💧','💦','☔','🔥','🌿','🍃','🍀','🌱','🌲','🌳','🌴','🌵','🎋','🎍','🍄','🌾','💐','🌷','🌹','🥀','🌺','🌸','🌼','🌻','🌞','🌝','🌛','🌜','🌚','🌙','💥','🔴','🟠','🟡','🟢','🔵','🟣','⚫','⚪','🟤','🪨','🌊','🫧','🌫','🌪','🌈','☄️','🪐','🌑','🌒','🌓','🌔','🌕','🌖','🌗','🌘','🪻','🪷','🌏','🍁','🍂','🌾','🎑','🏵','🎃','🎋','🎍'],
  // 8 Symboles & Signes
  ['💯','🔞','📵','🚫','❌','⭕','🛑','⛔','📛','🚷','🚯','🚳','🚱','📴','📳','🔇','📣','📢','🔔','🔕','🎵','🎶','💬','💭','🗨','🗯','💤','🔅','🔆','📶','🛜','📳','🔉','🔊','🔈','🔇','📣','📢','🔔','🔕','🔀','🔁','🔂','▶️','⏩','⏭','⏯','🔼','⏫','⏬','🔽','⏪','⏮','⏸','⏹','⏺','🎦','🔅','🔆','📶','📳','♾','🔱','⚜️','🏧','✅','☑️','🔲','🔳','▪️','▫️','◾','◽','◼','◻','⬛','⬜','🟥','🟧','🟨','🟩','🟦','🟪','⚫','⚪','🟫','🔶','🔷','🔸','🔹','🔺','🔻','💠','🔘','🔳','🔲','♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓','⛎'],
];
let epCurrentCat = 0;

function renderEpGrid(cat) {
  const grid = document.getElementById('epGrid');
  grid.innerHTML = '';
  EP_CATS[cat].forEach(em => {
    const d = document.createElement('div');
    d.className = 'ep-emoji';
    d.textContent = em;
    d.onclick = () => insertEmoji(em);
    grid.appendChild(d);
  });
}

function switchEpTab(cat) {
  epCurrentCat = cat;
  document.querySelectorAll('.ep-tab').forEach(t => t.classList.toggle('active', +t.dataset.cat === cat));
  renderEpGrid(cat);
}

function toggleEmoji(forceClose = false) {
  const p = document.getElementById('emojiPicker');
  if (forceClose) {
    p.classList.remove('open');
  } else {
    const opening = !p.classList.contains('open');
    p.classList.toggle('open');
    if (opening) renderEpGrid(epCurrentCat);
  }
}

function insertEmoji(em) {
  const input = document.getElementById('msgInput');
  const pos = input.selectionStart || input.value.length;
  input.value = input.value.slice(0, pos) + em + input.value.slice(pos);
  input.focus();
  input.selectionStart = input.selectionEnd = pos + em.length;
  document.getElementById('emojiPicker').classList.remove('open');
}

// ─── NOTIFICATION SOUND (doux) ───────────────────────────────────────────────
function playDmSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();

    function playNote(freq, startTime, duration, gainVal) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 1200;
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + startTime);
      gain.gain.setValueAtTime(0, ctx.currentTime + startTime);
      gain.gain.linearRampToValueAtTime(gainVal, ctx.currentTime + startTime + 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + startTime + duration);
      osc.start(ctx.currentTime + startTime);
      osc.stop(ctx.currentTime + startTime + duration + 0.05);
    }

    // Trois notes douces et courtes, attaque lente, volume très bas
    playNote(523, 0,    0.35, 0.07);
    playNote(659, 0.22, 0.35, 0.06);
    playNote(784, 0.42, 0.50, 0.05);
  } catch(e) {}
}

// ─── BLOCAGE ──────────────────────────────────────────────────────────────────
// ─── Correction audit M-04 : validation stricte du format ────────────────────
// Sans validation, une extension navigateur ou un XSS résiduel pourrait injecter
// des userId arbitraires (ex : BOT_ID) pour masquer des messages à la victime.
const blockedUsers = new Set(
  (() => {
    try {
      const raw = JSON.parse(localStorage.getItem('mychat_blocked') || '[]');
      if (!Array.isArray(raw)) return [];
      // Valider : tableau de chaînes alphanumériques de 1 à 32 chars (format userId serveur)
      return raw.filter(id => typeof id === 'string' && /^[a-z0-9]{1,32}$/i.test(id) && id !== 'ia_bot_mychat');
    } catch (_) { return []; }
  })()
);

function saveBlocked() {
  localStorage.setItem('mychat_blocked', JSON.stringify([...blockedUsers]));
}

function blockUser(userId) {
  blockedUsers.add(userId);
  saveBlocked();
  silencedDMs.add(userId);
  // Si on est en DM avec lui, retour au salon
  if (activeChat.type === 'private' && activeChat.id === userId) backToRoom();
  updateUsersList();
  showToast('🚫 Utilisateur bloqué');
}

function unblockUser(userId) {
  blockedUsers.delete(userId);
  saveBlocked();
  updateUsersList();
  showToast('✅ Utilisateur débloqué');
}

// ─── MENU CONTEXTUEL ─────────────────────────────────────────────────────────
let ctxMenuTarget = null;

function openUserCtxMenu(e, userId) {
  e.preventDefault();
  e.stopPropagation();
  const u = users[userId];
  if (!u || userId === me?.id) return;
  ctxMenuTarget = userId;

  const menu = document.getElementById('userCtxMenu');
  const isBlocked = blockedUsers.has(userId);

  const isBot = (userId === BOT_ID);
  let menuHtml = '<div class="user-ctx-header">' + escHtml(u.avatar) + ' ' + escHtml(u.name) + '</div>';
  menuHtml += '<div class="user-ctx-item" id="ctxDm">💬 ' + (isBot ? 'Discuter avec l\'IA' : 'Envoyer un message') + '</div>';
  if (!isBot) {
    menuHtml += '<div class="user-ctx-item" id="ctxWizz">⚡ Envoyer un Wizz</div>';
    menuHtml += '<div class="user-ctx-item ' + (isBlocked ? 'success' : 'danger') + '" id="ctxBlock">' + (isBlocked ? '✅ Débloquer' : '🚫 Bloquer') + '</div>';
  }
  menu.innerHTML = menuHtml;

  // Position
  const x = Math.min(e.clientX, window.innerWidth - 200);
  const y = Math.min(e.clientY, window.innerHeight - 140);
  menu.style.cssText = 'display:block; left:' + x + 'px; top:' + y + 'px;';

  menu.querySelector('#ctxDm').onclick = () => { closeCtxMenu(); openPrivateChat(userId); };
  if (!isBot) {
    menu.querySelector('#ctxWizz').onclick = () => {
      closeCtxMenu();
      openPrivateChat(userId);
      setTimeout(() => { activeChat.id === userId && sendWizz(); }, 100);
    };
    menu.querySelector('#ctxBlock').onclick = () => {
      closeCtxMenu();
      isBlocked ? unblockUser(userId) : blockUser(userId);
    };
  }
}

function closeCtxMenu() {
  document.getElementById('userCtxMenu').style.display = 'none';
  ctxMenuTarget = null;
}

document.addEventListener('click', () => closeCtxMenu());
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeCtxMenu(); });

// ─── WIZZ ─────────────────────────────────────────────────────────────────────
let wizzCooldown = false;

function sendWizz() {
  if (!me || activeChat.type !== 'private' || wizzCooldown || activeChat.id === BOT_ID) return;
  apiPost({ type: 'wizz', action: 'wizz', user: me, toId: activeChat.id });
  triggerWizzEffect(null);
  showWizzToast('⚡ Wizz envoyé !', '#f59e0b');
  wizzCooldown = true;
  const btn = document.getElementById('wizzBtn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Wizz...'; }
  setTimeout(() => {
    wizzCooldown = false;
    if (btn) { btn.disabled = false; btn.textContent = '⚡ Wizz'; }
  }, 10000);
}

function triggerWizzEffect(senderName) {
  const area = document.getElementById('messagesArea');
  area.classList.remove('wizz-shake');
  void area.offsetWidth;
  area.classList.add('wizz-shake');
  area.addEventListener('animationend', () => area.classList.remove('wizz-shake'), { once: true });
  playWizzSound();
}

function showWizzToast(msg, color) {
  const t = document.getElementById('wizzToast');
  if (!t) return;
  t.textContent = msg;
  t.style.borderColor = color || '#f59e0b';
  t.style.color = color || '#f59e0b';
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}

function playWizzSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    [0, 0.08, 0.16, 0.24, 0.32].forEach((t, i) => {
      const freqs = [440, 520, 440, 520, 600];
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.value = freqs[i];
      gain.gain.setValueAtTime(0, ctx.currentTime + t);
      gain.gain.linearRampToValueAtTime(0.12, ctx.currentTime + t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.07);
      osc.start(ctx.currentTime + t);
      osc.stop(ctx.currentTime + t + 0.1);
    });
  } catch(e) {}
}

(function startClock() {
  function tick() {
    const now = new Date();
    const h = String(now.getHours()).padStart(2, '0');
    const m = String(now.getMinutes()).padStart(2, '0');
    const s = String(now.getSeconds()).padStart(2, '0');
    const el = document.getElementById('liveClock');
    if (el) el.textContent = `${h}:${m}:${s}`;
  }
  tick();
  setInterval(tick, 1000);
})();

let toastImgTimer = null;
function showToastImg(user, imageUrl) {
  const el    = document.getElementById('toastImg');
  const thumb = document.getElementById('toastImgThumb');
  const name  = document.getElementById('toastImgName');
  if (!el) return;
  thumb.src        = imageUrl;
  name.textContent = `${user.avatar} ${user.name}`;
  el.classList.add('show');
  clearTimeout(toastImgTimer);
  toastImgTimer = setTimeout(() => el.classList.remove('show'), 4000);
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ─── MOBILE SIDEBAR ──────────────────────────────────────────────────────────
function toggleSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.getElementById('sidebarOverlay');
  const open = sidebar.classList.toggle('open');
  overlay.classList.toggle('open', open);
  document.body.style.overflow = open ? 'hidden' : '';
}
function closeSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.getElementById('sidebarOverlay');
  sidebar.classList.remove('open');
  overlay.classList.remove('open');
  document.body.style.overflow = '';
}

// ─── FIX CLAVIER VIRTUEL MOBILE ──────────────────────────────────────────────
// Sur mobile (iOS/Android), quand le clavier s'affiche, on scrolle en bas
// pour que les messages récents restent visibles.
if (window.visualViewport) {
  let lastVvHeight = window.visualViewport.height;
  window.visualViewport.addEventListener('resize', () => {
    const area = document.getElementById('messagesArea');
    if (!area || !me) return;
    const newHeight = window.visualViewport.height;
    // Le clavier vient de s'ouvrir (viewport réduit)
    if (newHeight < lastVvHeight - 80) {
      // Légère attente pour laisser le DOM se redessiner
      setTimeout(() => { area.scrollTop = area.scrollHeight; }, 80);
    }
    lastVvHeight = newHeight;
  });
}

document.getElementById('usersList').addEventListener('click', e => {
  const item = e.target.closest('.user-item[data-user-id]');
  if (item) openPrivateChat(item.dataset.userId);
});

document.addEventListener('click', e => {
  if (!e.target.closest('.emoji-btn') && !e.target.closest('.emoji-picker'))
    document.getElementById('emojiPicker')?.classList.remove('open');
});

// ─── BINDINGS (remplacent les onclick inline supprimés) ───────────────────────
document.getElementById('lightbox')      ?.addEventListener('click', closeLightbox);
document.getElementById('joinBtn')       ?.addEventListener('click', joinChat);
document.getElementById('sidebarOverlay')?.addEventListener('click', closeSidebar);
document.getElementById('leaveBtn')      ?.addEventListener('click', leaveChat);
document.getElementById('menuBtn')       ?.addEventListener('click', toggleSidebar);
document.getElementById('wizzBtn')       ?.addEventListener('click', sendWizz);
document.getElementById('dmBackBtn')     ?.addEventListener('click', backToRoom);
document.getElementById('emojiBtn')      ?.addEventListener('click', () => toggleEmoji());
document.getElementById('sendBtn')       ?.addEventListener('click', sendMessage);
document.getElementById('imgUploadBtn')  ?.addEventListener('click', () => document.getElementById('imgInput')?.click());
document.getElementById('imgInput')      ?.addEventListener('change', function() { onImageSelected(this); });
document.getElementById('msgInput')      ?.addEventListener('keydown', handleKey);
document.getElementById('msgInput')      ?.addEventListener('input', handleTyping);
document.getElementById('usernameInput') ?.addEventListener('input', checkPseudoAvailability);

// Délégation pour les onglets emoji (data-cat)
document.querySelector('.ep-tabs')?.addEventListener('click', e => {
  const tab = e.target.closest('.ep-tab[data-cat]');
  if (tab) switchEpTab(Number(tab.dataset.cat));
});