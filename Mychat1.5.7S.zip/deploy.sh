#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# deploy.sh — Pipeline de déploiement MyChat
#
# Ce script doit être exécuté depuis la racine du projet après chaque build.
# Il recalcule les hashes SRI (SHA-384) de style.css et app.js, puis met à
# jour les attributs integrity="…" dans index.html de façon atomique.
#
# Usage :
#   bash deploy.sh              # vérification + patch in-place
#   bash deploy.sh --dry-run    # affiche les nouveaux hashes sans modifier index.html
#
# Prérequis : openssl ≥ 1.1, sed, base64 (coreutils) — disponibles sur
#             macOS, Linux (Debian/Ubuntu/Alpine), et la plupart des CI/CD.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

INDEX="index.html"
DRY_RUN=false
[[ "${1:-}" == "--dry-run" ]] && DRY_RUN=true

# ─── Couleurs ────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "${GREEN}✔${NC}  $*"; }
warn() { echo -e "${YELLOW}⚠${NC}  $*"; }
fail() { echo -e "${RED}✘${NC}  $*" >&2; exit 1; }

# ─── Vérifications préalables ────────────────────────────────────────────────
for cmd in openssl sed base64; do
    command -v "$cmd" &>/dev/null || fail "Commande manquante : $cmd"
done

[[ -f "$INDEX" ]] || fail "Fichier introuvable : $INDEX"

# ─── Calcul des hashes SHA-384 ───────────────────────────────────────────────
# Compatibilité : openssl dgst renvoie un binaire → base64 pour l'encodage SRI.
sri_hash() {
    local file="$1"
    [[ -f "$file" ]] || fail "Fichier introuvable pour le hash SRI : $file"
    # -binary : sortie binaire brute (pas hex) — requis par la spec SRI
    openssl dgst -sha384 -binary "$file" | base64 | tr -d '\n'
}

CSS_FILE="style.css"
JS_FILE="app.js"

echo "⟳  Calcul des hashes SRI…"
CSS_HASH="sha384-$(sri_hash "$CSS_FILE")"
JS_HASH="sha384-$(sri_hash "$JS_FILE")"

echo ""
echo "   style.css → integrity=\"${CSS_HASH}\""
echo "   app.js    → integrity=\"${JS_HASH}\""
echo ""

if $DRY_RUN; then
    warn "Mode --dry-run : index.html NON modifié."
    exit 0
fi

# ─── Extraction des hashes actuels dans index.html ───────────────────────────
# Regex portables (BRE/ERE) sans lookbehind (POSIX).
current_css=$(grep -oE 'integrity="sha384-[A-Za-z0-9+/=]+"' "$INDEX" | grep "$CSS_FILE\|style" | head -1 | grep -oE 'sha384-[A-Za-z0-9+/=]+' || true)
current_js=$(grep -oE 'integrity="sha384-[A-Za-z0-9+/=]+"' "$INDEX" | tail -1 | grep -oE 'sha384-[A-Za-z0-9+/=]+' || true)

# Extraction plus robuste : on extrait les hashes dans l'ordre d'apparition
mapfile -t all_hashes < <(grep -oE 'integrity="sha384-[A-Za-z0-9+/=]+"' "$INDEX" | grep -oE 'sha384-[A-Za-z0-9+/=]+')

if [[ ${#all_hashes[@]} -lt 2 ]]; then
    fail "index.html ne contient pas deux attributs integrity= (attendu : style.css + app.js). Vérifiez le fichier."
fi

OLD_CSS_HASH="${all_hashes[0]}"
OLD_JS_HASH="${all_hashes[1]}"

# ─── Patch in-place de index.html ────────────────────────────────────────────
# On travaille sur une copie temporaire pour garantir l'atomicité.
TMP=$(mktemp "${INDEX}.XXXXXX")
trap 'rm -f "$TMP"' EXIT

cp "$INDEX" "$TMP"

# Remplacer les hashes dans le fichier temporaire.
# sed -i '' pour macOS, sed -i pour Linux.
SED_INPLACE=(-i)
[[ "$(uname)" == "Darwin" ]] && SED_INPLACE=(-i '')

sed "${SED_INPLACE[@]}" "s|${OLD_CSS_HASH}|${CSS_HASH}|g" "$TMP"
sed "${SED_INPLACE[@]}" "s|${OLD_JS_HASH}|${JS_HASH}|g"  "$TMP"

# Vérification : les nouveaux hashes doivent être présents dans le fichier patché
grep -q "${CSS_HASH}" "$TMP" || fail "Le hash style.css n'a pas été injecté dans index.html — vérifiez manuellement."
grep -q "${JS_HASH}"  "$TMP" || fail "Le hash app.js n'a pas été injecté dans index.html — vérifiez manuellement."

# Remplacement atomique
mv "$TMP" "$INDEX"
trap - EXIT

ok "index.html mis à jour avec les nouveaux hashes SRI."
echo ""

# ─── Vérification post-patch : les hashes dans index.html correspondent-ils aux fichiers ? ─
# Correction audit F-02 — sanity-check final pour détecter toute désynchronisation résiduelle.
echo "⟳  Vérification croisée hashes SRI…"
VERIFY_CSS=$(openssl dgst -sha384 -binary "$CSS_FILE" | base64 | tr -d '\n')
VERIFY_JS=$(openssl dgst -sha384 -binary "$JS_FILE"  | base64 | tr -d '\n')
grep -q "sha384-${VERIFY_CSS}" "$INDEX" || fail "VÉRIFICATION ÉCHOUÉE : le hash style.css dans index.html ne correspond PAS au fichier sur disque !"
grep -q "sha384-${VERIFY_JS}"  "$INDEX" || fail "VÉRIFICATION ÉCHOUÉE : le hash app.js dans index.html ne correspond PAS au fichier sur disque !"
ok "Vérification croisée OK — hashes cohérents avec les fichiers."
echo ""

# ─── Intégration CI/CD (correction audit F-02) ───────────────────────────────
# Ce script DOIT être exécuté automatiquement après chaque build, avant le déploiement.
# Exemples d'intégration :
#
#   GitHub Actions (.github/workflows/deploy.yml) :
#     - name: Update SRI hashes
#       run: bash deploy.sh
#
#   GitLab CI (.gitlab-ci.yml) :
#     sri:
#       script:
#         - bash deploy.sh
#       artifacts:
#         paths: [index.html]
#
#   Makefile :
#     deploy: build
#         bash deploy.sh
#         rsync -avz . user@server:/var/www/html/
#
# Sans cette automatisation, un déploiement sans re-générer les hashes
# rend l'application inaccessible (le navigateur refuse les ressources SRI invalides).

# ─── Rappel : mettre à jour le lien SRI si vous hébergez sur un CDN ──────────
warn "Pensez à invalider le cache CDN / Cloudflare après déploiement."
warn "Si vous utilisez un Content-Security-Policy avec 'require-sri-for script style', vérifiez qu'il est toujours valide."
echo ""
echo -e "${GREEN}Déploiement SRI terminé avec succès.${NC}"
